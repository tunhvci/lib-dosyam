import 'package:flutter/material.dart';
import 'package:no_name/app/app.dart';
import 'package:no_name/features/transactions/data/repositories/persistent_transaction_repository.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final repo = PersistentTransactionRepository();
  await repo.load();
  runApp(NoNameApp(transactionRepository: repo));
}
