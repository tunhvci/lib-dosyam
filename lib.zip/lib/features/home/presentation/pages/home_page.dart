import 'package:flutter/material.dart';
import 'package:no_name/core/theme/app_colors.dart';
import 'package:no_name/features/transactions/domain/entities/finance_transaction.dart';
import 'package:no_name/features/transactions/domain/usecases/add_transaction.dart';

class HomePage extends StatefulWidget {
  const HomePage({
    required this.addTransaction,
    required this.onTransactionAdded,
    super.key,
  });

  final AddTransaction addTransaction;
  final VoidCallback onTransactionAdded;

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final _controller = TextEditingController();
  final _focusNode = FocusNode();
  bool _isProcessing = false;

  @override
  void dispose() {
    _controller.dispose();
    _focusNode.dispose();
    super.dispose();
  }

  Future<void> _processInput(bool isCredit) async {
    final text = _controller.text.trim();
    if (text.isEmpty) return;

    setState(() => _isProcessing = true);

    final result = _parseNaturalLanguage(text, isCredit);

    if (result != null) {
      await widget.addTransaction(
        FinanceTransaction(
          id: DateTime.now().microsecondsSinceEpoch.toString(),
          date: result.date,
          title: result.title,
          amount: result.amount,
          isCredit: isCredit,
          category: isCredit ? null : result.category,
        ),
      );

      widget.onTransactionAdded();
      _controller.clear();

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              isCredit
                  ? '✓ Income added: ${result.title} - ₺${result.amount}'
                  : '✓ Expense added: ${result.title} - ₺${result.amount}',
            ),
            duration: const Duration(seconds: 2),
            behavior: SnackBarBehavior.floating,
          ),
        );
      }
    } else {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text(
              '❌ Could not understand. Example: "coffee 50" or "kahve \$5"',
            ),
            duration: Duration(seconds: 2),
            behavior: SnackBarBehavior.floating,
          ),
        );
      }
    }

    setState(() => _isProcessing = false);
  }

  _ParseResult? _parseNaturalLanguage(String text, bool isCredit) {
    text = text.toLowerCase().trim();

    // Sayı çıkar (₺, tl, lira, $, dollar ile)
    final amountRegex = RegExp(
      r'(?:\$|₺)?\s*(\d+(?:[.,]\d+)?)\s*(?:₺|tl|lira|\$|dollar|dollars)?',
    );
    final amountMatch = amountRegex.firstMatch(text);

    if (amountMatch == null) return null;

    final amountStr = amountMatch.group(1)!.replaceAll(',', '.');
    final amount = double.tryParse(amountStr);

    if (amount == null || amount <= 0) return null;

    // Tarih çıkar - gelişmiş tarih ayrıştırma
    DateTime date = DateTime.now();

    // "X gün önce" / "X days ago"
    final daysAgoRegex = RegExp(
      r'(\d+)\s*(?:gün|gun|day|days)\s*(?:önce|once|ago)',
    );
    final daysAgoMatch = daysAgoRegex.firstMatch(text);
    if (daysAgoMatch != null) {
      final days = int.tryParse(daysAgoMatch.group(1)!) ?? 0;
      date = date.subtract(Duration(days: days));
    }

    // "X gün sonra" / "in X days" / "X days later"
    final daysLaterRegex = RegExp(
      r'(?:(\d+)\s*(?:gün|gun|day|days)\s*(?:sonra|later)|in\s*(\d+)\s*(?:day|days))',
    );
    final daysLaterMatch = daysLaterRegex.firstMatch(text);
    if (daysLaterMatch != null) {
      final days =
          int.tryParse(
            daysLaterMatch.group(1) ?? daysLaterMatch.group(2) ?? '0',
          ) ??
          0;
      date = date.add(Duration(days: days));
    }

    // "yarın" / "tomorrow"
    if (text.contains('yarın') ||
        text.contains('yarin') ||
        text.contains('tomorrow')) {
      date = date.add(const Duration(days: 1));
    }

    // "dün" / "yesterday"
    if (text.contains('dün') ||
        text.contains('dun') ||
        text.contains('yesterday')) {
      date = date.subtract(const Duration(days: 1));
    }

    // "gelecek hafta" / "next week"
    if (text.contains('gelecek hafta') || text.contains('next week')) {
      date = date.add(const Duration(days: 7));
    }

    // "geçen hafta" / "last week"
    if (text.contains('geçen hafta') ||
        text.contains('gecen hafta') ||
        text.contains('last week')) {
      date = date.subtract(const Duration(days: 7));
    }

    // Başlık ve kategori çıkar
    String title = text
        .replaceAll(amountMatch.group(0)!, '')
        .replaceAll(
          RegExp(
            r'\b(verdim|ödedim|odedim|harcadım|harcadim|aldım|aldim|için|icin|bugün|bugun|dün|dun|yarın|yarin|'
            r'paid|spent|bought|for|today|yesterday|tomorrow|ago|later|sonra|önce|once|'
            r'\d+\s*(?:gün|gun|day|days)|gelecek|geçen|gecen|hafta|week|next|last|in)\b',
          ),
          '',
        )
        .trim();

    if (title.isEmpty) {
      title = isCredit ? 'Income' : 'Expense';
    } else {
      // İlk harfi büyük yap
      title = title[0].toUpperCase() + title.substring(1);
    }

    // Kategori tahmin et (only for expenses)
    TxCategory? category;
    if (!isCredit) {
      category = _guessCategory(text);
    }

    return _ParseResult(
      amount: amount,
      title: title,
      date: date,
      category: category,
    );
  }

  TxCategory _guessCategory(String text) {
    // Gelişmiş kategori tahmin sistemi - öncelik sırasına göre

    // 1. Kira / Rent (yüksek öncelik)
    if (_containsAny(text, [
      'kira',
      'rent',
      'ev kirası',
      'ev kirasi',
      'house rent',
      'apartment',
      'daire',
    ])) {
      return TxCategory.rent;
    }

    // 2. Faturalar / Bills
    if (_containsAny(text, [
      'fatura',
      'bill',
      'elektrik',
      'electricity',
      'electric',
      'su faturası',
      'su faturasi',
      'water bill',
      'water',
      'doğalgaz',
      'dogalgaz',
      'natural gas',
      'gas bill',
      'internet',
      'wifi',
      'telefon',
      'phone',
      'mobile',
      'utility',
      'utilities',
      'abonelik',
      'subscription',
    ])) {
      return TxCategory.bills;
    }

    // 3. Yemek / Food (çok detaylı)
    if (_containsAny(text, [
      // Market
      'market',
      'süpermarket',
      'supermarket',
      'grocery',
      'groceries',
      'migros',
      'carrefour',
      'a101',
      'bim',
      'şok',
      'sok',
      // Yemek genel
      'yemek',
      'food',
      'meal',
      'eat',
      'ate',
      // Kahve
      'kahve',
      'coffee',
      'starbucks',
      'cafe',
      'kafe',
      'espresso',
      'latte',
      'cappuccino',
      // Öğünler
      'kahvaltı',
      'kahvalti',
      'breakfast',
      'öğle',
      'ogle',
      'öğlen',
      'oglen',
      'lunch',
      'akşam',
      'aksam',
      'dinner',
      'supper',
      // Restoran
      'restoran',
      'restaurant',
      'lokanta',
      'yemek yedim',
      'yemek yedik',
      // Fast food
      'burger',
      'pizza',
      'kebap',
      'döner',
      'doner',
      'sandwich',
      'sandviç',
      'sandvic',
      // Atıştırmalık
      'snack',
      'atıştırmalık',
      'atistirmalik',
      'çikolata',
      'cikolata',
      'chocolate',
      'chips',
      'cips',
    ])) {
      return TxCategory.food;
    }

    // 4. Ulaşım / Transport
    if (_containsAny(text, [
      'benzin',
      'fuel',
      'gas',
      'petrol',
      'yakıt',
      'yakit',
      'otobüs',
      'otobus',
      'bus',
      'metro',
      'subway',
      'taksi',
      'taxi',
      'uber',
      'bolt',
      'bitaksi',
      'ulaşım',
      'ulasim',
      'transport',
      'transportation',
      'bilet',
      'ticket',
      'istanbulkart',
      'akbil',
      'park',
      'parking',
      'otopark',
      'toll',
      'köprü',
      'kopru',
      'bridge',
    ])) {
      return TxCategory.transport;
    }

    // 5. Sağlık / Health
    if (_containsAny(text, [
      'doktor',
      'doctor',
      'dr',
      'eczane',
      'pharmacy',
      'drugstore',
      'hastane',
      'hospital',
      'clinic',
      'klinik',
      'ilaç',
      'ilac',
      'medicine',
      'medication',
      'drug',
      'sağlık',
      'saglik',
      'health',
      'medical',
      'tedavi',
      'treatment',
      'muayene',
      'examination',
      'tahlil',
      'test',
      'lab',
      'röntgen',
      'rontgen',
      'x-ray',
      'diş',
      'dis',
      'dental',
      'dentist',
      'gözlük',
      'gozluk',
      'glasses',
      'lens',
    ])) {
      return TxCategory.health;
    }

    // 6. Alışveriş / Shopping
    if (_containsAny(text, [
      'alışveriş',
      'alisveris',
      'shopping',
      'shop',
      'kıyafet',
      'kiyafet',
      'clothes',
      'clothing',
      'giyim',
      'wear',
      'ayakkabı',
      'ayakkabi',
      'shoes',
      'sneakers',
      'bot',
      'boots',
      'apparel',
      'tişört',
      'tisort',
      't-shirt',
      'tshirt',
      'pantolon',
      'pants',
      'jeans',
      'kot',
      'ceket',
      'jacket',
      'mont',
      'coat',
      'elbise',
      'dress',
      'etek',
      'skirt',
      'çanta',
      'canta',
      'bag',
      'purse',
      'aksesuar',
      'accessory',
      'accessories',
      'zara',
      'h&m',
      'mango',
      'lcw',
      'defacto',
    ])) {
      return TxCategory.shopping;
    }

    // 7. Kişisel bakım / Personal Care
    if (_containsAny(text, [
      'kuaför',
      'kuafor',
      'hairdresser',
      'hair salon',
      'berber',
      'barber',
      'güzellik',
      'guzellik',
      'beauty',
      'salon',
      'saç',
      'sac',
      'hair',
      'haircut',
      'saç kesimi',
      'sac kesimi',
      'manikür',
      'manikur',
      'manicure',
      'pedikür',
      'pedikur',
      'pedicure',
      'masaj',
      'massage',
      'spa',
      'cilt bakımı',
      'cilt bakimi',
      'skincare',
      'kozmetik',
      'cosmetics',
      'makeup',
      'makyaj',
    ])) {
      return TxCategory.personalCare;
    }

    // Varsayılan: extra
    return TxCategory.extra;
  }

  // Yardımcı fonksiyon: text içinde keywords'lerden herhangi biri var mı?
  bool _containsAny(String text, List<String> keywords) {
    for (final keyword in keywords) {
      if (text.contains(keyword)) {
        return true;
      }
    }
    return false;
  }

  @override
  Widget build(BuildContext context) {
    final c = context.appColors;
    return Scaffold(
      backgroundColor: c.background,
      body: SafeArea(
        child: Column(
          children: [
            // Header
            Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      color: c.card,
                      shape: BoxShape.circle,
                      border: Border.all(color: c.border),
                    ),
                    child: Center(
                      child: Text(
                        'A',
                        style: TextStyle(
                          color: c.textPrimary,
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ),
                  Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      color: c.card,
                      shape: BoxShape.circle,
                      border: Border.all(color: c.border),
                    ),
                    child: Icon(
                      Icons.settings_outlined,
                      color: c.textSecondary,
                      size: 20,
                    ),
                  ),
                ],
              ),
            ),

            // Content
            Expanded(
              child: GestureDetector(
                onTap: () => _focusNode.unfocus(),
                child: SingleChildScrollView(
                  padding: const EdgeInsets.symmetric(horizontal: 24),
                  child: Column(
                    children: [
                      const SizedBox(height: 20),
                      // Başlık
                      Text(
                        'What did\nyou do?',
                        style: Theme.of(context).textTheme.titleLarge?.copyWith(
                          fontSize: 36,
                          fontWeight: FontWeight.w700,
                          letterSpacing: -1,
                          height: 1.2,
                        ),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'Write naturally, I\'ll understand',
                        style: TextStyle(
                          color: c.textSecondary,
                          fontSize: 13,
                          fontWeight: FontWeight.w400,
                        ),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 32),

                      // Text field
                      Container(
                        decoration: BoxDecoration(
                          color: c.card,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: c.border, width: 1),
                        ),
                        child: TextField(
                          controller: _controller,
                          focusNode: _focusNode,
                          maxLines: 3,
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            color: c.textPrimary,
                            fontSize: 15,
                            height: 1.4,
                            fontWeight: FontWeight.w400,
                          ),
                          decoration: InputDecoration(
                            hintText: 'coffee 50\nrent 8000\nwork 15',
                            hintStyle: TextStyle(
                              color: c.textMuted,
                              fontSize: 14,
                              height: 1.5,
                              fontWeight: FontWeight.w400,
                            ),
                            border: InputBorder.none,
                            contentPadding: const EdgeInsets.all(20),
                          ),
                        ),
                      ),
                      const SizedBox(height: 16),

                      // Butonlar
                      Row(
                        children: [
                          Expanded(
                            child: _ActionButton(
                              label: 'Expense',
                              icon: Icons.remove_circle_outline,
                              color: c.negativeText,
                              bg: c.negativeBg,
                              isProcessing: _isProcessing,
                              onTap: () => _processInput(false),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: _ActionButton(
                              label: 'Income',
                              icon: Icons.add_circle_outline,
                              color: c.positiveText,
                              bg: c.positiveBg,
                              isProcessing: _isProcessing,
                              onTap: () => _processInput(true),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 40),
                    ],
                  ),
                ),
              ),
            ),

            // Bottom Navigation
            Container(
              decoration: BoxDecoration(
                color: c.card,
                border: Border(top: BorderSide(color: c.border, width: 1)),
              ),
              child: SafeArea(
                top: false,
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      _NavItem(
                        icon: Icons.home_outlined,
                        label: 'Home',
                        isActive: true,
                        color: c,
                      ),
                      _NavItem(
                        icon: Icons.grid_view_outlined,
                        label: 'Monthly',
                        isActive: false,
                        color: c,
                      ),
                      _NavItem(
                        icon: Icons.calendar_view_week_outlined,
                        label: 'Weekly',
                        isActive: false,
                        color: c,
                      ),
                      _NavItem(
                        icon: Icons.bar_chart_outlined,
                        label: 'Stats',
                        isActive: false,
                        color: c,
                      ),
                      _NavItem(
                        icon: Icons.pie_chart_outline,
                        label: 'Charts',
                        isActive: false,
                        color: c,
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ParseResult {
  const _ParseResult({
    required this.amount,
    required this.title,
    required this.date,
    this.category,
  });

  final double amount;
  final String title;
  final DateTime date;
  final TxCategory? category;
}

class _ActionButton extends StatelessWidget {
  const _ActionButton({
    required this.label,
    required this.icon,
    required this.color,
    required this.bg,
    required this.isProcessing,
    required this.onTap,
  });

  final String label;
  final IconData icon;
  final Color color;
  final Color bg;
  final bool isProcessing;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: isProcessing ? null : onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 16),
        decoration: BoxDecoration(
          color: bg,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: color.withValues(alpha: 0.2), width: 1),
        ),
        child: isProcessing
            ? Center(
                child: SizedBox(
                  width: 18,
                  height: 18,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    valueColor: AlwaysStoppedAnimation<Color>(color),
                  ),
                ),
              )
            : Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(icon, color: color, size: 18),
                  const SizedBox(width: 8),
                  Text(
                    label,
                    style: TextStyle(
                      color: color,
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
      ),
    );
  }
}

class _NavItem extends StatelessWidget {
  const _NavItem({
    required this.icon,
    required this.label,
    required this.isActive,
    required this.color,
  });

  final IconData icon;
  final String label;
  final bool isActive;
  final dynamic color;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(
          icon,
          color: isActive ? color.positiveText : color.textSecondary,
          size: 24,
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: TextStyle(
            color: isActive ? color.textPrimary : color.textSecondary,
            fontSize: 11,
            fontWeight: isActive ? FontWeight.w600 : FontWeight.w400,
          ),
        ),
      ],
    );
  }
}
