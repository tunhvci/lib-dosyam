import 'dart:math' as math;

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:no_name/core/theme/app_colors.dart';
import 'package:no_name/features/transactions/domain/entities/finance_transaction.dart';
import 'package:no_name/features/transactions/domain/usecases/get_all_transactions.dart';

class ChartsPage extends StatefulWidget {
  const ChartsPage({
    required this.getAllTransactions,
    required this.txVersionListenable,
    super.key,
  });

  final GetAllTransactions getAllTransactions;
  final ValueListenable<int> txVersionListenable;

  @override
  State<ChartsPage> createState() => _ChartsPageState();
}

enum _ChartRange { month, week }

class _ChartsPageState extends State<ChartsPage> {
  _ChartRange _range = _ChartRange.month;
  late DateTime _anchor = DateTime.now();

  DateTime get _periodStart {
    if (_range == _ChartRange.month) {
      return DateTime(_anchor.year, _anchor.month, 1);
    }
    final day = DateTime(_anchor.year, _anchor.month, _anchor.day);
    final diff = day.weekday - 1;
    return day.subtract(Duration(days: diff));
  }

  DateTime get _periodEnd {
    if (_range == _ChartRange.month) {
      return DateTime(_anchor.year, _anchor.month + 1, 0, 23, 59, 59, 999);
    }
    final start = _periodStart;
    return DateTime(start.year, start.month, start.day + 6, 23, 59, 59, 999);
  }

  void _shiftPeriod(int direction) {
    setState(() {
      if (_range == _ChartRange.month) {
        _anchor = DateTime(_anchor.year, _anchor.month + direction, 1);
      } else {
        _anchor = _anchor.add(Duration(days: 7 * direction));
      }
    });
  }

  String _periodLabel() {
    if (_range == _ChartRange.month) {
      const months = [
        'January',
        'February',
        'March',
        'April',
        'May',
        'June',
        'July',
        'August',
        'September',
        'October',
        'November',
        'December',
      ];
      return '${months[_anchor.month - 1]} ${_anchor.year}';
    }
    final start = _periodStart;
    final end = _periodEnd;
    const shortMonths = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec',
    ];
    if (start.month == end.month) {
      return '${start.day}-${end.day} ${shortMonths[start.month - 1]} ${start.year}';
    }
    return '${start.day} ${shortMonths[start.month - 1]} - ${end.day} ${shortMonths[end.month - 1]} ${start.year}';
  }

  // Kategori renkleri — tüm temalarda okunabilir, mat tonlar
  static const _catColors = {
    TxCategory.rent: Color(0xFF7B9CCC),
    TxCategory.bills: Color(0xFFB8956A),
    TxCategory.food: Color(0xFF6DB87A),
    TxCategory.transport: Color(0xFF6AAEC0),
    TxCategory.health: Color(0xFFC08070),
    TxCategory.shopping: Color(0xFFAA78B8),
    TxCategory.personalCare: Color(0xFF8090C8),
    TxCategory.extra: Color(0xFFA87898),
  };

  @override
  Widget build(BuildContext context) {
    final c = context.appColors;
    return ValueListenableBuilder<int>(
      valueListenable: widget.txVersionListenable,
      builder: (context, version, child) {
        final all = widget.getAllTransactions();
        final start = _periodStart;
        final end = _periodEnd;
        final periodTx = all
            .where((tx) => !tx.date.isBefore(start) && !tx.date.isAfter(end))
            .where((tx) => !tx.isCredit && tx.category != null)
            .toList(growable: false);

        final totals = <TxCategory, double>{};
        final counts = <TxCategory, int>{};
        for (final tx in periodTx) {
          totals[tx.category!] = (totals[tx.category!] ?? 0) + tx.amount;
          counts[tx.category!] = (counts[tx.category!] ?? 0) + 1;
        }
        final grand = totals.values.fold<double>(0, (a, b) => a + b);
        final entries = totals.entries.toList()
          ..sort((a, b) => b.value.compareTo(a.value));

        return Scaffold(
          backgroundColor: c.background,
          body: SafeArea(
            child: Column(
              children: [
                // Header
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(
                        width: 40,
                        height: 40,
                        decoration: BoxDecoration(
                          color: c.card,
                          shape: BoxShape.circle,
                          border: Border.all(color: c.border),
                        ),
                        child: Center(
                          child: Text(
                            'A',
                            style: TextStyle(
                              color: c.textPrimary,
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ),
                      Container(
                        width: 40,
                        height: 40,
                        decoration: BoxDecoration(
                          color: c.card,
                          shape: BoxShape.circle,
                          border: Border.all(color: c.border),
                        ),
                        child: Icon(
                          Icons.settings_outlined,
                          color: c.textSecondary,
                          size: 20,
                        ),
                      ),
                    ],
                  ),
                ),

                // Content
                Expanded(
                  child: ListView(
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    children: [
                      const SizedBox(height: 8),
                      _RangePill(
                        value: _range,
                        onChanged: (next) => setState(() => _range = next),
                      ),
                      const SizedBox(height: 20),
                      Row(
                        children: [
                          _ArrowBtn(
                            icon: Icons.chevron_left_rounded,
                            onTap: () => _shiftPeriod(-1),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Text(
                              _periodLabel(),
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                color: c.textPrimary,
                                fontSize: 14,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                          const SizedBox(width: 10),
                          _ArrowBtn(
                            icon: Icons.chevron_right_rounded,
                            onTap: () => _shiftPeriod(1),
                          ),
                        ],
                      ),
                      const SizedBox(height: 20),
                      Text(
                        'Spending by category',
                        style: TextStyle(
                          color: c.textSecondary,
                          fontSize: 11,
                          letterSpacing: 0.5,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      const SizedBox(height: 20),
                      if (grand <= 0)
                        Container(
                          padding: const EdgeInsets.all(20),
                          decoration: BoxDecoration(
                            color: c.card,
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: c.border, width: 0.5),
                          ),
                          child: Center(
                            child: Text(
                              'No categorized spending data for this period yet.',
                              style: TextStyle(
                                color: c.textMuted,
                                fontSize: 13,
                              ),
                            ),
                          ),
                        )
                      else
                        Container(
                          padding: const EdgeInsets.all(20),
                          decoration: BoxDecoration(
                            color: c.card,
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: c.border, width: 0.5),
                          ),
                          child: Row(
                            children: [
                              SizedBox(
                                width: 140,
                                height: 140,
                                child: Stack(
                                  alignment: Alignment.center,
                                  children: [
                                    Positioned.fill(
                                      child: CustomPaint(
                                        painter: _DonutPainter(
                                          slices: entries
                                              .map(
                                                (entry) => _DonutSlice(
                                                  value: entry.value,
                                                  color:
                                                      _catColors[entry.key] ??
                                                      c.textSecondary,
                                                ),
                                              )
                                              .toList(growable: false),
                                          grand: grand,
                                          bgColor: c.border,
                                        ),
                                      ),
                                    ),
                                    Container(
                                      width: 80,
                                      height: 80,
                                      decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        color: c.background,
                                      ),
                                      child: Center(
                                        child: Text(
                                          _money(grand),
                                          style: TextStyle(
                                            color: c.textPrimary,
                                            fontSize: 16,
                                            fontWeight: FontWeight.w600,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(width: 20),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: entries
                                      .map((entry) {
                                        final pct = (entry.value / grand) * 100;
                                        final pctText =
                                            '${pct.toStringAsFixed(0)}%';
                                        final color =
                                            _catColors[entry.key] ??
                                            c.textSecondary;
                                        return Padding(
                                          padding: const EdgeInsets.symmetric(
                                            vertical: 6,
                                          ),
                                          child: Row(
                                            children: [
                                              Container(
                                                width: 8,
                                                height: 8,
                                                decoration: BoxDecoration(
                                                  color: color,
                                                  shape: BoxShape.circle,
                                                ),
                                              ),
                                              const SizedBox(width: 8),
                                              Expanded(
                                                child: Text(
                                                  entry.key.label,
                                                  style: TextStyle(
                                                    color: c.textSecondary,
                                                    fontSize: 12,
                                                  ),
                                                ),
                                              ),
                                              Text(
                                                pctText,
                                                style: TextStyle(
                                                  color: c.textSecondary,
                                                  fontSize: 12,
                                                  fontWeight: FontWeight.w500,
                                                ),
                                              ),
                                            ],
                                          ),
                                        );
                                      })
                                      .toList(growable: false),
                                ),
                              ),
                            ],
                          ),
                        ),
                      if (grand > 0) ...[
                        const SizedBox(height: 24),
                        Text(
                          'Category details',
                          style: TextStyle(
                            color: c.textSecondary,
                            fontSize: 11,
                            letterSpacing: 0.5,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        const SizedBox(height: 12),
                        ...entries.map((entry) {
                          final pct = (entry.value / grand) * 100;
                          final color =
                              _catColors[entry.key] ?? c.textSecondary;
                          return _CategoryDetailCard(
                            label: entry.key.label,
                            amountText: _money(entry.value),
                            countText:
                                '${counts[entry.key] ?? 0} transaction${counts[entry.key] == 1 ? '' : 's'}',
                            pct: pct,
                            color: color,
                          );
                        }),
                      ],
                      const SizedBox(height: 32),
                    ],
                  ),
                ),

                // Bottom Navigation
                Container(
                  decoration: BoxDecoration(
                    color: c.card,
                    border: Border(top: BorderSide(color: c.border, width: 1)),
                  ),
                  child: SafeArea(
                    top: false,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          _NavItem(
                            icon: Icons.home_outlined,
                            label: 'Home',
                            isActive: false,
                            color: c,
                          ),
                          _NavItem(
                            icon: Icons.grid_view_outlined,
                            label: 'Monthly',
                            isActive: false,
                            color: c,
                          ),
                          _NavItem(
                            icon: Icons.calendar_view_week_outlined,
                            label: 'Weekly',
                            isActive: false,
                            color: c,
                          ),
                          _NavItem(
                            icon: Icons.bar_chart_outlined,
                            label: 'Daily',
                            isActive: false,
                            color: c,
                          ),
                          _NavItem(
                            icon: Icons.pie_chart_outline,
                            label: 'Charts',
                            isActive: true,
                            color: c,
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  String _money(double n) =>
      '₺${n.toStringAsFixed(n == n.roundToDouble() ? 0 : 2)}';
}

class _RangePill extends StatelessWidget {
  const _RangePill({required this.value, required this.onChanged});
  final _ChartRange value;
  final ValueChanged<_ChartRange> onChanged;

  @override
  Widget build(BuildContext context) {
    final c = context.appColors;
    return Container(
      height: 36,
      padding: const EdgeInsets.all(3),
      decoration: BoxDecoration(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: c.border, width: 0.7),
      ),
      child: Row(
        children: [
          _RangeChip(
            label: 'Month',
            selected: value == _ChartRange.month,
            onTap: () => onChanged(_ChartRange.month),
          ),
          const SizedBox(width: 4),
          _RangeChip(
            label: 'Week',
            selected: value == _ChartRange.week,
            onTap: () => onChanged(_ChartRange.week),
          ),
        ],
      ),
    );
  }
}

class _RangeChip extends StatelessWidget {
  const _RangeChip({
    required this.label,
    required this.selected,
    required this.onTap,
  });
  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final c = context.appColors;
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: selected ? c.surface : Colors.transparent,
            borderRadius: BorderRadius.circular(9),
          ),
          child: Text(
            label,
            style: TextStyle(
              color: selected ? c.textPrimary : c.textSecondary,
              fontSize: 12,
              fontWeight: selected ? FontWeight.w600 : FontWeight.w500,
            ),
          ),
        ),
      ),
    );
  }
}

class _ArrowBtn extends StatelessWidget {
  const _ArrowBtn({required this.icon, required this.onTap});
  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final c = context.appColors;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 32,
        height: 32,
        decoration: BoxDecoration(
          color: c.card,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: c.border, width: 0.5),
        ),
        child: Icon(icon, color: c.textSecondary, size: 18),
      ),
    );
  }
}

class _CategoryDetailCard extends StatelessWidget {
  const _CategoryDetailCard({
    required this.label,
    required this.amountText,
    required this.countText,
    required this.pct,
    required this.color,
  });

  final String label;
  final String amountText;
  final String countText;
  final double pct;
  final Color color;

  @override
  Widget build(BuildContext context) {
    final c = context.appColors;
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: c.card,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: c.border, width: 0.5),
      ),
      child: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  label,
                  style: TextStyle(
                    color: c.textPrimary,
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
              Text(
                amountText,
                style: TextStyle(
                  color: c.textPrimary,
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(width: 6),
              Text(
                '${pct.toStringAsFixed(0)}%',
                style: TextStyle(
                  color: c.textMuted,
                  fontSize: 11,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: LinearProgressIndicator(
                    minHeight: 5,
                    value: (pct / 100).clamp(0, 1),
                    backgroundColor: c.border.withValues(alpha: 0.5),
                    valueColor: AlwaysStoppedAnimation<Color>(color),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Text(
                countText,
                style: TextStyle(color: c.textMuted, fontSize: 10),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _DonutSlice {
  const _DonutSlice({required this.value, required this.color});
  final double value;
  final Color color;
}

class _DonutPainter extends CustomPainter {
  _DonutPainter({
    required this.slices,
    required this.grand,
    required this.bgColor,
  });

  final List<_DonutSlice> slices;
  final double grand;
  final Color bgColor;

  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width / 2;
    final cy = size.height / 2;
    final outerR = math.min(cx, cy) - 3;
    final innerR = outerR * 0.62;
    final rect = Rect.fromCircle(center: Offset(cx, cy), radius: outerR);
    final ringStroke = outerR - innerR;

    double startAngle = -math.pi / 2;
    final gap = slices.length <= 1 ? 0.0 : 0.045;

    for (final slice in slices) {
      final sweep = (slice.value / grand) * 2 * math.pi - gap;
      if (sweep <= 0) continue;
      final segmentPaint = Paint()
        ..shader = SweepGradient(
          startAngle: startAngle + gap / 2,
          endAngle: startAngle + gap / 2 + sweep,
          colors: [slice.color, slice.color],
        ).createShader(rect)
        ..style = PaintingStyle.stroke
        ..strokeWidth = ringStroke
        ..strokeCap = StrokeCap.butt;
      canvas.drawArc(rect, startAngle + gap / 2, sweep, false, segmentPaint);
      startAngle += sweep + gap;
    }
  }

  @override
  bool shouldRepaint(_DonutPainter old) =>
      old.slices != slices || old.grand != grand || old.bgColor != bgColor;
}

class _NavItem extends StatelessWidget {
  const _NavItem({
    required this.icon,
    required this.label,
    required this.isActive,
    required this.color,
  });

  final IconData icon;
  final String label;
  final bool isActive;
  final dynamic color;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(
          icon,
          color: isActive ? color.positiveText : color.textSecondary,
          size: 24,
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: TextStyle(
            color: isActive ? color.textPrimary : color.textSecondary,
            fontSize: 11,
            fontWeight: isActive ? FontWeight.w600 : FontWeight.w400,
          ),
        ),
      ],
    );
  }
}
