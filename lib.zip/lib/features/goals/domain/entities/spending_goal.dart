class SpendingGoal {
  const SpendingGoal({
    required this.id,
    required this.type,
    required this.targetAmount,
    required this.currentAmount,
  });

  final String id;
  final GoalType type;
  final double targetAmount;
  final double currentAmount;

  double get percentage {
    if (targetAmount == 0) return 0;
    return (currentAmount / targetAmount * 100).clamp(0, 100);
  }

  bool get isOverBudget => currentAmount > targetAmount;

  SpendingGoal copyWith({
    String? id,
    GoalType? type,
    double? targetAmount,
    double? currentAmount,
  }) {
    return SpendingGoal(
      id: id ?? this.id,
      type: type ?? this.type,
      targetAmount: targetAmount ?? this.targetAmount,
      currentAmount: currentAmount ?? this.currentAmount,
    );
  }
}

enum GoalType {
  daily,
  weekly,
  monthly;

  String get label {
    switch (this) {
      case GoalType.daily:
        return 'daily';
      case GoalType.weekly:
        return 'weekly';
      case GoalType.monthly:
        return 'monthly';
    }
  }
}
