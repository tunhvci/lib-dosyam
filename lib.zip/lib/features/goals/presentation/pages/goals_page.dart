import 'package:flutter/material.dart';
import 'package:no_name/core/theme/app_colors.dart';
import 'package:no_name/features/goals/domain/entities/spending_goal.dart';
import 'package:no_name/features/transactions/domain/usecases/get_all_transactions.dart';
import 'package:shared_preferences/shared_preferences.dart';

class GoalsPage extends StatefulWidget {
  const GoalsPage({required this.getAllTransactions, super.key});

  final GetAllTransactions getAllTransactions;

  @override
  State<GoalsPage> createState() => _GoalsPageState();
}

class _GoalsPageState extends State<GoalsPage> {
  final TextEditingController _noteController = TextEditingController();

  // Default goals - will be loaded from SharedPreferences
  List<SpendingGoal> _goals = [
    const SpendingGoal(
      id: '1',
      type: GoalType.daily,
      targetAmount: 0,
      currentAmount: 0,
    ),
    const SpendingGoal(
      id: '2',
      type: GoalType.weekly,
      targetAmount: 0,
      currentAmount: 0,
    ),
    const SpendingGoal(
      id: '3',
      type: GoalType.monthly,
      targetAmount: 0,
      currentAmount: 0,
    ),
  ];

  @override
  void initState() {
    super.initState();
    _loadGoals();
    _loadNote();
    _calculateCurrentSpending();
  }

  Future<void> _loadGoals() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _goals = [
        SpendingGoal(
          id: '1',
          type: GoalType.daily,
          targetAmount: prefs.getDouble('goal_daily') ?? 0,
          currentAmount: _goals[0].currentAmount,
        ),
        SpendingGoal(
          id: '2',
          type: GoalType.weekly,
          targetAmount: prefs.getDouble('goal_weekly') ?? 0,
          currentAmount: _goals[1].currentAmount,
        ),
        SpendingGoal(
          id: '3',
          type: GoalType.monthly,
          targetAmount: prefs.getDouble('goal_monthly') ?? 0,
          currentAmount: _goals[2].currentAmount,
        ),
      ];
    });
  }

  Future<void> _loadNote() async {
    final prefs = await SharedPreferences.getInstance();
    _noteController.text = prefs.getString('goals_note') ?? '';
  }

  Future<void> _saveNote() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('goals_note', _noteController.text);
  }

  void _calculateCurrentSpending() {
    final allTxs = widget.getAllTransactions();
    final now = DateTime.now();

    // Daily spending (today)
    final dailyExpenses = allTxs
        .where(
          (tx) =>
              !tx.isCredit &&
              tx.date.year == now.year &&
              tx.date.month == now.month &&
              tx.date.day == now.day,
        )
        .fold<double>(0, (sum, tx) => sum + tx.amount);

    // Weekly spending (last 7 days)
    final weekStart = now.subtract(Duration(days: now.weekday - 1));
    final weeklyExpenses = allTxs
        .where(
          (tx) =>
              !tx.isCredit &&
              tx.date.isAfter(weekStart.subtract(const Duration(days: 1))),
        )
        .fold<double>(0, (sum, tx) => sum + tx.amount);

    // Monthly spending (this month)
    final monthlyExpenses = allTxs
        .where(
          (tx) =>
              !tx.isCredit &&
              tx.date.year == now.year &&
              tx.date.month == now.month,
        )
        .fold<double>(0, (sum, tx) => sum + tx.amount);

    setState(() {
      _goals = [
        _goals[0].copyWith(currentAmount: dailyExpenses),
        _goals[1].copyWith(currentAmount: weeklyExpenses),
        _goals[2].copyWith(currentAmount: monthlyExpenses),
      ];
    });
  }

  double get netBalance {
    final allTxs = widget.getAllTransactions();
    final income = allTxs
        .where((tx) => tx.isCredit)
        .fold<double>(0, (sum, tx) => sum + tx.amount);
    final expenses = allTxs
        .where((tx) => !tx.isCredit)
        .fold<double>(0, (sum, tx) => sum + tx.amount);
    return income - expenses;
  }

  @override
  void dispose() {
    _saveNote();
    _noteController.dispose();
    super.dispose();
  }

  Future<void> _editGoal(GoalType type) async {
    final goal = _goals.firstWhere((g) => g.type == type);
    final controller = TextEditingController(
      text: goal.targetAmount > 0 ? goal.targetAmount.toStringAsFixed(0) : '',
    );

    final result = await showDialog<double>(
      context: context,
      builder: (ctx) {
        final c = context.appColors;
        return AlertDialog(
          backgroundColor: c.card,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
          title: Text(
            'Set ${type.label} goal',
            style: TextStyle(
              color: c.textPrimary,
              fontSize: 18,
              fontWeight: FontWeight.w600,
            ),
          ),
          content: TextField(
            controller: controller,
            keyboardType: TextInputType.number,
            autofocus: true,
            style: TextStyle(color: c.textPrimary, fontSize: 16),
            decoration: InputDecoration(
              labelText: 'Target amount',
              labelStyle: TextStyle(color: c.textSecondary),
              prefixText: '₺',
              prefixStyle: TextStyle(color: c.textPrimary),
              enabledBorder: UnderlineInputBorder(
                borderSide: BorderSide(color: c.border),
              ),
              focusedBorder: UnderlineInputBorder(
                borderSide: BorderSide(color: c.textPrimary),
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: Text('Cancel', style: TextStyle(color: c.textSecondary)),
            ),
            TextButton(
              onPressed: () {
                final amount = double.tryParse(controller.text);
                if (amount != null && amount >= 0) {
                  Navigator.pop(ctx, amount);
                }
              },
              child: Text('Save', style: TextStyle(color: c.textPrimary)),
            ),
          ],
        );
      },
    );

    if (result != null) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setDouble('goal_${type.name}', result);

      setState(() {
        final index = _goals.indexWhere((g) => g.type == type);
        _goals[index] = _goals[index].copyWith(targetAmount: result);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final c = context.appColors;
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: c.textPrimary),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(24, 0, 24, 24),
        children: [
          // Header
          Row(
            children: [
              Icon(Icons.flag_outlined, color: c.textPrimary, size: 28),
              const SizedBox(width: 12),
              Text(
                'Spending Goals',
                style: Theme.of(context).textTheme.titleLarge?.copyWith(
                  fontSize: 28,
                  fontWeight: FontWeight.w700,
                  letterSpacing: -0.5,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            'Set and track your spending limits',
            style: TextStyle(color: c.textSecondary, fontSize: 15),
          ),
          const SizedBox(height: 32),

          // Goals Card
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: c.card,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: c.border, width: 1),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text(
                      'SPEND GOALS',
                      style: TextStyle(
                        color: c.textMuted,
                        fontSize: 11,
                        letterSpacing: 1.2,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const Spacer(),
                    Container(
                      width: 8,
                      height: 8,
                      decoration: BoxDecoration(
                        color: c.positiveText,
                        shape: BoxShape.circle,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 24),

                // Goals list
                ..._goals.map(
                  (goal) =>
                      _GoalItem(goal: goal, onTap: () => _editGoal(goal.type)),
                ),

                const SizedBox(height: 32),

                // Net balance
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Net Balance',
                      style: TextStyle(
                        color: c.textMuted,
                        fontSize: 13,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '₺${netBalance.toStringAsFixed(0)}',
                      style: TextStyle(
                        color: c.textPrimary,
                        fontSize: 48,
                        fontWeight: FontWeight.w700,
                        letterSpacing: -1.5,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Total income minus total expenses',
                      style: TextStyle(color: c.textSecondary, fontSize: 12),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),

          // Notes section
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: c.card,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: c.border, width: 1),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(Icons.note_outlined, color: c.textSecondary, size: 20),
                    const SizedBox(width: 8),
                    Text(
                      'Notes',
                      style: TextStyle(
                        color: c.textPrimary,
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                TextField(
                  controller: _noteController,
                  maxLines: 5,
                  onChanged: (_) => _saveNote(),
                  style: TextStyle(
                    color: c.textPrimary,
                    fontSize: 14,
                    height: 1.5,
                  ),
                  decoration: InputDecoration(
                    hintText:
                        'Write your financial notes here...\n\nExample:\n• Save for vacation\n• Reduce coffee expenses\n• Pay rent on 1st',
                    hintStyle: TextStyle(
                      color: c.textMuted,
                      fontSize: 14,
                      height: 1.5,
                    ),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide(color: c.border),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide(color: c.border),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide(color: c.textPrimary, width: 1.5),
                    ),
                    contentPadding: const EdgeInsets.all(16),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),

          // Info card
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: c.surface,
              borderRadius: BorderRadius.circular(4),
              border: Border.all(color: c.border, width: 0.5),
            ),
            child: Row(
              children: [
                Icon(Icons.info_outline, color: c.textSecondary, size: 20),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    'Tap on any goal to edit the target amount',
                    style: TextStyle(color: c.textSecondary, fontSize: 13),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _GoalItem extends StatelessWidget {
  const _GoalItem({required this.goal, required this.onTap});

  final SpendingGoal goal;
  final VoidCallback onTap;

  Color _getProgressColor(BuildContext context, double percentage) {
    if (percentage >= 90) return Colors.red;
    if (percentage >= 70) return Colors.orange;
    return context.appColors.positiveText;
  }

  @override
  Widget build(BuildContext context) {
    final c = context.appColors;
    final percentage = goal.percentage;
    final progressColor = _getProgressColor(context, percentage);

    return GestureDetector(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.only(bottom: 20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Text(
                  goal.type.label,
                  style: TextStyle(
                    color: c.textSecondary,
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                const Spacer(),
                if (goal.targetAmount > 0) ...[
                  Text(
                    '${percentage.toStringAsFixed(0)}%',
                    style: TextStyle(
                      color: c.textSecondary,
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(width: 16),
                ],
                Text(
                  '₺${goal.currentAmount.toStringAsFixed(0)}',
                  style: TextStyle(
                    color: c.textPrimary,
                    fontSize: 15,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            ClipRRect(
              borderRadius: BorderRadius.circular(4),
              child: SizedBox(
                height: 6,
                child: Stack(
                  children: [
                    Container(width: double.infinity, color: c.border),
                    if (goal.targetAmount > 0)
                      FractionallySizedBox(
                        widthFactor: (percentage / 100).clamp(0.0, 1.0),
                        child: Container(color: progressColor),
                      ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
