import 'package:home_widget/home_widget.dart';

class WidgetService {
  static Future<void> updateWidget({
    required double dailySpent,
    required double dailyGoal,
    required double weeklySpent,
    required double weeklyGoal,
    required double monthlySpent,
    required double monthlyGoal,
    required double netBalance,
  }) async {
    try {
      // Calculate percentages
      final dailyPercent =
          (dailyGoal > 0 ? (dailySpent / dailyGoal * 100) : 0.0).toDouble();
      final weeklyPercent =
          (weeklyGoal > 0 ? (weeklySpent / weeklyGoal * 100) : 0.0).toDouble();
      final monthlyPercent =
          (monthlyGoal > 0 ? (monthlySpent / monthlyGoal * 100) : 0.0)
              .toDouble();

      // Save data for widget
      await HomeWidget.saveWidgetData<double>('daily_spent', dailySpent);
      await HomeWidget.saveWidgetData<double>('daily_goal', dailyGoal);
      await HomeWidget.saveWidgetData<double>('daily_percent', dailyPercent);

      await HomeWidget.saveWidgetData<double>('weekly_spent', weeklySpent);
      await HomeWidget.saveWidgetData<double>('weekly_goal', weeklyGoal);
      await HomeWidget.saveWidgetData<double>('weekly_percent', weeklyPercent);

      await HomeWidget.saveWidgetData<double>('monthly_spent', monthlySpent);
      await HomeWidget.saveWidgetData<double>('monthly_goal', monthlyGoal);
      await HomeWidget.saveWidgetData<double>(
        'monthly_percent',
        monthlyPercent,
      );

      await HomeWidget.saveWidgetData<double>('net_balance', netBalance);

      // Update widget
      await HomeWidget.updateWidget(
        name: 'SpendingGoalsWidget',
        iOSName: 'SpendingGoalsWidget',
        androidName: 'SpendingGoalsWidget',
      );
    } catch (e) {
      // Widget update failed, but app should continue
      // ignore: avoid_print
      print('Widget update failed: $e');
    }
  }

  static Future<void> initializeWidget() async {
    try {
      await HomeWidget.setAppGroupId('group.no_name.spending');
    } catch (e) {
      // ignore: avoid_print
      print('Widget initialization failed: $e');
    }
  }
}
