abstract class AppStartupRepository {
  Future<Duration> getStartupDelay();
}
