import 'package:no_name/features/splash/domain/repositories/app_startup_repository.dart';

class GetStartupDelay {
  const GetStartupDelay(this._repository);

  final AppStartupRepository _repository;

  Future<Duration> call() {
    return _repository.getStartupDelay();
  }
}
