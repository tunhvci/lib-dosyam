import 'package:no_name/features/splash/domain/repositories/app_startup_repository.dart';

class AppStartupRepositoryImpl implements AppStartupRepository {
  @override
  Future<Duration> getStartupDelay() async {
    return const Duration(seconds: 1);
  }
}
