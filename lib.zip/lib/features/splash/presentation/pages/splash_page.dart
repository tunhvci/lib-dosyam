import 'package:flutter/material.dart';
import 'package:no_name/core/theme/app_colors.dart';
import 'package:no_name/features/splash/domain/usecases/get_startup_delay.dart';

class SplashPage extends StatefulWidget {
  const SplashPage({
    required this.getStartupDelay,
    required this.onCompleted,
    super.key,
  });

  final GetStartupDelay getStartupDelay;
  final VoidCallback onCompleted;

  @override
  State<SplashPage> createState() => _SplashPageState();
}

class _SplashPageState extends State<SplashPage> {
  @override
  void initState() {
    super.initState();
    _start();
  }

  Future<void> _start() async {
    final delay = await widget.getStartupDelay();
    await Future<void>.delayed(delay);
    if (mounted) widget.onCompleted();
  }

  @override
  Widget build(BuildContext context) {
    final c = context.appColors;
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 56),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Spacer(flex: 2),
            Container(
              width: 36,
              height: 2,
              decoration: BoxDecoration(
                color: c.positiveText,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(height: 28),
            Text(
              'Welcome.',
              style: Theme.of(context).textTheme.headlineLarge?.copyWith(
                fontSize: 48,
                fontWeight: FontWeight.w600,
                letterSpacing: -1,
              ),
            ),
            const SizedBox(height: 16),
            Text(
              'we are here to\ncalculate your plan...',
              style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                color: c.textSecondary,
                fontSize: 18,
                height: 1.5,
                fontWeight: FontWeight.w300,
              ),
            ),
            const Spacer(flex: 3),
          ],
        ),
      ),
    );
  }
}
