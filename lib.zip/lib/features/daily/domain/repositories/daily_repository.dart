import 'package:no_name/features/daily/domain/entities/daily_overview.dart';

abstract class DailyRepository {
  Future<DailyOverview> getDailyOverview();
}
