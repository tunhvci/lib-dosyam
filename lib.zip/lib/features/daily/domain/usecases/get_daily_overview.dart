import 'package:no_name/features/daily/domain/entities/daily_overview.dart';
import 'package:no_name/features/daily/domain/repositories/daily_repository.dart';

class GetDailyOverview {
  const GetDailyOverview(this._repository);

  final DailyRepository _repository;

  Future<DailyOverview> call() {
    return _repository.getDailyOverview();
  }
}
