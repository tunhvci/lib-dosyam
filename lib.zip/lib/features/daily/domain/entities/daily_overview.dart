class DailyTransaction {
  const DailyTransaction({
    required this.label,
    required this.amount,
    required this.isCredit,
  });

  final String label;
  final String amount;
  final bool isCredit;
}

class DailyOverview {
  const DailyOverview({
    required this.dateLabel,
    required this.totalCredit,
    required this.totalCost,
    required this.transactions,
  });

  final String dateLabel;
  final String totalCredit;
  final String totalCost;
  final List<DailyTransaction> transactions;
}
