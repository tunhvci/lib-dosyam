import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:no_name/core/theme/app_colors.dart';
import 'package:no_name/features/transactions/domain/entities/finance_transaction.dart';
import 'package:no_name/features/transactions/domain/usecases/get_transactions_by_date.dart';

class DailyPage extends StatefulWidget {
  const DailyPage({
    required this.selectedDateListenable,
    required this.txVersionListenable,
    required this.getTransactionsByDate,
    required this.onDateChanged,
    super.key,
  });

  final ValueListenable<DateTime> selectedDateListenable;
  final ValueListenable<int> txVersionListenable;
  final GetTransactionsByDate getTransactionsByDate;
  final ValueChanged<DateTime> onDateChanged;

  @override
  State<DailyPage> createState() => _DailyPageState();
}

class _DailyPageState extends State<DailyPage>
    with SingleTickerProviderStateMixin {
  late final AnimationController _animCtrl;
  late Animation<double> _fade;
  late Animation<Offset> _slide;
  bool _goingForward = true;

  @override
  void initState() {
    super.initState();
    _animCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 180),
      value: 1.0,
    );
    _buildAnims();
  }

  void _buildAnims() {
    _fade = CurvedAnimation(parent: _animCtrl, curve: Curves.easeOutCubic);
    _slide = Tween<Offset>(
      begin: Offset(_goingForward ? 0.04 : -0.04, 0),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _animCtrl, curve: Curves.easeOutCubic));
  }

  Future<void> _goTo(DateTime date, bool forward) async {
    _goingForward = forward;
    _buildAnims();
    _animCtrl.value = 0;
    widget.onDateChanged(date);
    await _animCtrl.forward();
  }

  @override
  void dispose() {
    _animCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final c = context.appColors;
    return ValueListenableBuilder<int>(
      valueListenable: widget.txVersionListenable,
      builder: (context, _, _) => ValueListenableBuilder<DateTime>(
        valueListenable: widget.selectedDateListenable,
        builder: (context, selectedDate, _) {
          final transactions = widget.getTransactionsByDate(selectedDate);
          final totalIncome = _sum(transactions.where((e) => e.isCredit));
          final totalExpense = _sum(transactions.where((e) => !e.isCredit));

          return Scaffold(
            backgroundColor: c.background,
            body: SafeArea(
              child: Column(
                children: [
                  // Header
                  Padding(
                    padding: const EdgeInsets.all(16),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                          width: 40,
                          height: 40,
                          decoration: BoxDecoration(
                            color: c.card,
                            shape: BoxShape.circle,
                            border: Border.all(color: c.border),
                          ),
                          child: Center(
                            child: Text(
                              'A',
                              style: TextStyle(
                                color: c.textPrimary,
                                fontSize: 16,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                        ),
                        Container(
                          width: 40,
                          height: 40,
                          decoration: BoxDecoration(
                            color: c.card,
                            shape: BoxShape.circle,
                            border: Border.all(color: c.border),
                          ),
                          child: Icon(
                            Icons.settings_outlined,
                            color: c.textSecondary,
                            size: 20,
                          ),
                        ),
                      ],
                    ),
                  ),

                  // Content
                  Expanded(
                    child: GestureDetector(
                      onHorizontalDragEnd: (details) {
                        if (details.primaryVelocity == null) return;
                        if (details.primaryVelocity! < -200) {
                          _goTo(
                            selectedDate.add(const Duration(days: 1)),
                            true,
                          );
                        } else if (details.primaryVelocity! > 200) {
                          _goTo(
                            selectedDate.subtract(const Duration(days: 1)),
                            false,
                          );
                        }
                      },
                      child: FadeTransition(
                        opacity: _fade,
                        child: SlideTransition(
                          position: _slide,
                          child: ListView(
                            padding: const EdgeInsets.symmetric(horizontal: 20),
                            children: [
                              const SizedBox(height: 8),
                              // Header + ok butonları
                              Row(
                                children: [
                                  Expanded(
                                    child: Text(
                                      _dateLabel(selectedDate),
                                      style: TextStyle(
                                        color: c.textPrimary,
                                        fontSize: 32,
                                        fontWeight: FontWeight.w700,
                                        letterSpacing: -1,
                                        height: 1.2,
                                      ),
                                    ),
                                  ),
                                  _ArrowBtn(
                                    icon: Icons.chevron_left_rounded,
                                    onTap: () => _goTo(
                                      selectedDate.subtract(
                                        const Duration(days: 1),
                                      ),
                                      false,
                                    ),
                                  ),
                                  const SizedBox(width: 6),
                                  _ArrowBtn(
                                    icon: Icons.chevron_right_rounded,
                                    onTap: () => _goTo(
                                      selectedDate.add(const Duration(days: 1)),
                                      true,
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 28),

                              // Totals
                              Row(
                                children: [
                                  Expanded(
                                    child: _StatItem(
                                      label: 'TOTAL INCOME',
                                      value: _money(totalIncome),
                                      color: c.positiveText,
                                    ),
                                  ),
                                  const SizedBox(width: 20),
                                  Expanded(
                                    child: _StatItem(
                                      label: 'TOTAL EXPENSE',
                                      value: _money(totalExpense),
                                      color: c.negativeText,
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 28),

                              Text(
                                'Transactions',
                                style: TextStyle(
                                  color: c.textSecondary,
                                  fontSize: 11,
                                  letterSpacing: 0.5,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                              const SizedBox(height: 12),

                              Container(
                                decoration: BoxDecoration(
                                  color: c.card,
                                  borderRadius: BorderRadius.circular(12),
                                  border: Border.all(
                                    color: c.border,
                                    width: 0.5,
                                  ),
                                ),
                                child: transactions.isEmpty
                                    ? Padding(
                                        padding: const EdgeInsets.all(20),
                                        child: Center(
                                          child: Text(
                                            'No transactions for this day yet.',
                                            style: TextStyle(
                                              color: c.textMuted,
                                              fontSize: 13,
                                            ),
                                          ),
                                        ),
                                      )
                                    : Column(
                                        children: [
                                          for (
                                            int i = 0;
                                            i < transactions.length;
                                            i++
                                          ) ...[
                                            _TransactionRow(
                                              tx: transactions[i],
                                              money: _money,
                                            ),
                                            if (i < transactions.length - 1)
                                              Divider(
                                                height: 1,
                                                indent: 14,
                                                endIndent: 14,
                                                color: c.border,
                                              ),
                                          ],
                                        ],
                                      ),
                              ),
                              const SizedBox(height: 32),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),

                  // Bottom Navigation
                  Container(
                    decoration: BoxDecoration(
                      color: c.card,
                      border: Border(
                        top: BorderSide(color: c.border, width: 1),
                      ),
                    ),
                    child: SafeArea(
                      top: false,
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 8),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            _NavItem(
                              icon: Icons.home_outlined,
                              label: 'Home',
                              isActive: false,
                              color: c,
                            ),
                            _NavItem(
                              icon: Icons.grid_view_outlined,
                              label: 'Monthly',
                              isActive: false,
                              color: c,
                            ),
                            _NavItem(
                              icon: Icons.calendar_view_week_outlined,
                              label: 'Weekly',
                              isActive: false,
                              color: c,
                            ),
                            _NavItem(
                              icon: Icons.bar_chart_outlined,
                              label: 'Daily',
                              isActive: true,
                              color: c,
                            ),
                            _NavItem(
                              icon: Icons.pie_chart_outline,
                              label: 'Charts',
                              isActive: false,
                              color: c,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  double _sum(Iterable<FinanceTransaction> txs) =>
      txs.fold<double>(0, (s, tx) => s + tx.amount);

  String _money(double value) {
    if (value == value.roundToDouble()) return '₺${value.toStringAsFixed(0)}';
    return '₺${value.toStringAsFixed(2)}';
  }

  String _dateLabel(DateTime date) {
    const months = [
      'January',
      'February',
      'March',
      'April',
      'May',
      'June',
      'July',
      'August',
      'September',
      'October',
      'November',
      'December',
    ];
    return '${date.day} ${months[date.month - 1]} ${date.year}';
  }
}

// ── Sub-widgets ──────────────────────────────────────────────────────────────

class _ArrowBtn extends StatelessWidget {
  const _ArrowBtn({required this.icon, required this.onTap});
  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final c = context.appColors;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 32,
        height: 32,
        decoration: BoxDecoration(
          color: c.card,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: c.border, width: 0.5),
        ),
        child: Icon(icon, color: c.textSecondary, size: 18),
      ),
    );
  }
}

class _StatItem extends StatelessWidget {
  const _StatItem({
    required this.label,
    required this.value,
    required this.color,
  });

  final String label;
  final String value;
  final Color color;

  @override
  Widget build(BuildContext context) {
    final c = context.appColors;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            color: c.textSecondary,
            fontSize: 9,
            letterSpacing: 0.8,
            fontWeight: FontWeight.w500,
          ),
        ),
        const SizedBox(height: 6),
        Text(
          value,
          style: TextStyle(
            color: color,
            fontSize: 22,
            fontWeight: FontWeight.w600,
            letterSpacing: -0.5,
          ),
        ),
      ],
    );
  }
}

class _TransactionRow extends StatelessWidget {
  const _TransactionRow({required this.tx, required this.money});

  final FinanceTransaction tx;
  final String Function(double) money;

  @override
  Widget build(BuildContext context) {
    final c = context.appColors;
    final color = tx.isCredit ? c.positiveText : c.negativeText;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
      child: Row(
        children: [
          Container(
            width: 6,
            height: 6,
            decoration: BoxDecoration(color: color, shape: BoxShape.circle),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  tx.title,
                  style: TextStyle(
                    color: c.textPrimary,
                    fontSize: 14,
                    fontWeight: FontWeight.w400,
                  ),
                ),
                if (tx.category != null)
                  Text(
                    tx.category!.label,
                    style: TextStyle(color: c.textMuted, fontSize: 11),
                  ),
              ],
            ),
          ),
          Text(
            '${tx.isCredit ? '+' : '−'}${money(tx.amount)}',
            style: TextStyle(
              color: color,
              fontSize: 14,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }
}

class _NavItem extends StatelessWidget {
  const _NavItem({
    required this.icon,
    required this.label,
    required this.isActive,
    required this.color,
  });

  final IconData icon;
  final String label;
  final bool isActive;
  final dynamic color;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(
          icon,
          color: isActive ? color.positiveText : color.textSecondary,
          size: 24,
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: TextStyle(
            color: isActive ? color.textPrimary : color.textSecondary,
            fontSize: 11,
            fontWeight: isActive ? FontWeight.w600 : FontWeight.w400,
          ),
        ),
      ],
    );
  }
}
