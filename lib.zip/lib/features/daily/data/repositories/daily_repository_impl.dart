import 'package:no_name/features/daily/domain/entities/daily_overview.dart';
import 'package:no_name/features/daily/domain/repositories/daily_repository.dart';

class DailyRepositoryImpl implements DailyRepository {
  @override
  Future<DailyOverview> getDailyOverview() async {
    return const DailyOverview(
      dateLabel: '27th December',
      totalCredit: '₺850',
      totalCost: '₺77',
      transactions: [
        DailyTransaction(label: 'Food', amount: '₺150', isCredit: true),
        DailyTransaction(label: 'Something', amount: '₺45', isCredit: false),
        DailyTransaction(label: 'Freelance', amount: '₺500', isCredit: true),
        DailyTransaction(label: 'Transport', amount: '₺32', isCredit: false),
        DailyTransaction(label: 'Bonus', amount: '₺200', isCredit: true),
      ],
    );
  }
}
