import 'package:no_name/features/weekly/domain/entities/weekly_overview.dart';
import 'package:no_name/features/weekly/domain/repositories/weekly_repository.dart';

class WeeklyRepositoryImpl implements WeeklyRepository {
  @override
  Future<WeeklyOverview> getWeeklyOverview() async {
    return const WeeklyOverview(
      weekLabel: '24th - 28th Dec 2026',
      dayLabel: 'Saturday, Dec 26',
      totalDayExpense: '₺0',
      totalDayIncome: '₺0',
      totalWeekIncome: '₺0',
      totalWeekExpense: '₺0',
      transactions: [],
    );
  }
}
