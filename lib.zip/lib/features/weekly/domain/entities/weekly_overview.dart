class WeeklyTransaction {
  const WeeklyTransaction({
    required this.label,
    required this.amount,
    required this.isCredit,
  });

  final String label;
  final String amount;
  final bool isCredit;
}

class WeeklyOverview {
  const WeeklyOverview({
    required this.weekLabel,
    required this.dayLabel,
    required this.totalDayExpense,
    required this.totalDayIncome,
    required this.totalWeekIncome,
    required this.totalWeekExpense,
    required this.transactions,
  });

  final String weekLabel;
  final String dayLabel;
  final String totalDayExpense;
  final String totalDayIncome;
  final String totalWeekIncome;
  final String totalWeekExpense;
  final List<WeeklyTransaction> transactions;
}
