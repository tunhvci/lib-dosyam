import 'package:no_name/features/weekly/domain/entities/weekly_overview.dart';

abstract class WeeklyRepository {
  Future<WeeklyOverview> getWeeklyOverview();
}
