import 'package:no_name/features/weekly/domain/entities/weekly_overview.dart';
import 'package:no_name/features/weekly/domain/repositories/weekly_repository.dart';

class GetWeeklyOverview {
  const GetWeeklyOverview(this._repository);

  final WeeklyRepository _repository;

  Future<WeeklyOverview> call() {
    return _repository.getWeeklyOverview();
  }
}
