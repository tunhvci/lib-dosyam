import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:no_name/core/theme/app_colors.dart';
import 'package:no_name/features/transactions/domain/entities/finance_transaction.dart';
import 'package:no_name/features/transactions/domain/usecases/delete_transaction.dart';
import 'package:no_name/features/transactions/domain/usecases/get_transactions_by_date.dart';
import 'package:no_name/features/transactions/domain/usecases/update_transaction.dart';

class WeeklyPage extends StatefulWidget {
  const WeeklyPage({
    required this.selectedDateListenable,
    required this.txVersionListenable,
    required this.getTransactionsByDate,
    required this.updateTransaction,
    required this.deleteTransaction,
    required this.onTxChanged,
    super.key,
  });

  final ValueListenable<DateTime> selectedDateListenable;
  final ValueListenable<int> txVersionListenable;
  final GetTransactionsByDate getTransactionsByDate;
  final UpdateTransaction updateTransaction;
  final DeleteTransaction deleteTransaction;
  final VoidCallback onTxChanged;

  @override
  State<WeeklyPage> createState() => _WeeklyPageState();
}

class _WeeklyPageState extends State<WeeklyPage>
    with SingleTickerProviderStateMixin {
  late DateTime _weekStart;
  late final AnimationController _animCtrl;
  late Animation<double> _fade;
  late Animation<Offset> _slide;
  bool _goingForward = true;

  @override
  void initState() {
    super.initState();
    _weekStart = _sundayStart(widget.selectedDateListenable.value);
    _animCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 200),
      value: 1.0,
    );
    _buildAnims();
  }

  void _buildAnims() {
    _fade = CurvedAnimation(parent: _animCtrl, curve: Curves.easeOutCubic);
    _slide = Tween<Offset>(
      begin: Offset(_goingForward ? 0.04 : -0.04, 0),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _animCtrl, curve: Curves.easeOutCubic));
  }

  Future<void> _changeWeek(DateTime newStart, bool forward) async {
    _goingForward = forward;
    _buildAnims();
    _animCtrl.value = 0;
    setState(() => _weekStart = newStart);
    await _animCtrl.forward();
  }

  DateTime _sundayStart(DateTime date) {
    final d = DateTime(date.year, date.month, date.day);
    final offset = d.weekday % 7;
    return d.subtract(Duration(days: offset));
  }

  @override
  void dispose() {
    _animCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final c = context.appColors;
    return ValueListenableBuilder<int>(
      valueListenable: widget.txVersionListenable,
      builder: (context, _, _) {
        final days = List.generate(7, (i) => _weekStart.add(Duration(days: i)));
        final weeklyTxs = days
            .expand((d) => widget.getTransactionsByDate(d))
            .toList();
        final weekIncome = _sum(weeklyTxs.where((e) => e.isCredit));

        final selDate = widget.selectedDateListenable.value;
        final displayDate = days.any((d) => _isSameDay(d, selDate))
            ? selDate
            : days[0];
        final dayTxs = widget.getTransactionsByDate(displayDate);
        final dayExpense = _sum(dayTxs.where((e) => !e.isCredit));

        final activeDays = days
            .where((d) => widget.getTransactionsByDate(d).isNotEmpty)
            .toList();

        return Scaffold(
          backgroundColor: c.background,
          body: SafeArea(
            child: Column(
              children: [
                // Header
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(
                        width: 40,
                        height: 40,
                        decoration: BoxDecoration(
                          color: c.card,
                          shape: BoxShape.circle,
                          border: Border.all(color: c.border),
                        ),
                        child: Center(
                          child: Text(
                            'A',
                            style: TextStyle(
                              color: c.textPrimary,
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ),
                      Container(
                        width: 40,
                        height: 40,
                        decoration: BoxDecoration(
                          color: c.card,
                          shape: BoxShape.circle,
                          border: Border.all(color: c.border),
                        ),
                        child: Icon(
                          Icons.settings_outlined,
                          color: c.textSecondary,
                          size: 20,
                        ),
                      ),
                    ],
                  ),
                ),

                // Content
                Expanded(
                  child: ListView(
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    children: [
                      const SizedBox(height: 8),
                      // Header + oklar
                      Row(
                        children: [
                          Expanded(
                            child: FadeTransition(
                              opacity: _fade,
                              child: Text(
                                _weekLabel(_weekStart),
                                style: TextStyle(
                                  color: c.textPrimary,
                                  fontSize: 32,
                                  fontWeight: FontWeight.w700,
                                  letterSpacing: -1,
                                  height: 1.2,
                                ),
                              ),
                            ),
                          ),
                          _ArrowBtn(
                            icon: Icons.chevron_left_rounded,
                            onTap: () => _changeWeek(
                              _weekStart.subtract(const Duration(days: 7)),
                              false,
                            ),
                          ),
                          const SizedBox(width: 6),
                          _ArrowBtn(
                            icon: Icons.chevron_right_rounded,
                            onTap: () => _changeWeek(
                              _weekStart.add(const Duration(days: 7)),
                              true,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 28),

                      // İstatistikler
                      Row(
                        children: [
                          Expanded(
                            child: _StatItem(
                              label: 'WEEKLY INCOME',
                              value: _money(weekIncome),
                              color: c.positiveText,
                            ),
                          ),
                          const SizedBox(width: 20),
                          Expanded(
                            child: _StatItem(
                              label: 'DAILY EXPENSE',
                              value: _money(dayExpense),
                              color: c.negativeText,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 32),

                      // 7 günlük bar listesi
                      FadeTransition(
                        opacity: _fade,
                        child: SlideTransition(
                          position: _slide,
                          child: Column(
                            children: days
                                .map(
                                  (day) => _DayRow(
                                    date: day,
                                    txs: widget.getTransactionsByDate(day),
                                    isSelected: _isSameDay(day, displayDate),
                                  ),
                                )
                                .toList(),
                          ),
                        ),
                      ),

                      // İşlem detayları
                      if (activeDays.isNotEmpty) ...[
                        const SizedBox(height: 24),
                        FadeTransition(
                          opacity: _fade,
                          child: SlideTransition(
                            position: _slide,
                            child: Column(
                              children: () {
                                final sections = <Widget>[];
                                for (final day in activeDays) {
                                  final txs = widget.getTransactionsByDate(day);
                                  if (txs.isEmpty) continue;
                                  if (sections.isNotEmpty) {
                                    sections.add(const SizedBox(height: 24));
                                  }
                                  sections.add(
                                    _DaySection(
                                      date: day,
                                      transactions: txs,
                                      money: _money,
                                      isToday: _isSameDay(day, DateTime.now()),
                                      onEdit: _editTx,
                                      onDelete: _deleteTx,
                                    ),
                                  );
                                }
                                return sections;
                              }(),
                            ),
                          ),
                        ),
                        const SizedBox(height: 32),
                      ],
                    ],
                  ),
                ),

                // Bottom Navigation
                Container(
                  decoration: BoxDecoration(
                    color: c.card,
                    border: Border(top: BorderSide(color: c.border, width: 1)),
                  ),
                  child: SafeArea(
                    top: false,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          _NavItem(
                            icon: Icons.home_outlined,
                            label: 'Home',
                            isActive: false,
                            color: c,
                          ),
                          _NavItem(
                            icon: Icons.grid_view_outlined,
                            label: 'Monthly',
                            isActive: false,
                            color: c,
                          ),
                          _NavItem(
                            icon: Icons.calendar_view_week_outlined,
                            label: 'Weekly',
                            isActive: true,
                            color: c,
                          ),
                          _NavItem(
                            icon: Icons.bar_chart_outlined,
                            label: 'Stats',
                            isActive: false,
                            color: c,
                          ),
                          _NavItem(
                            icon: Icons.pie_chart_outline,
                            label: 'Charts',
                            isActive: false,
                            color: c,
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Future<void> _editTx(FinanceTransaction tx) async {
    final titleCtrl = TextEditingController(text: tx.title);
    final amountCtrl = TextEditingController(
      text: tx.amount == tx.amount.roundToDouble()
          ? tx.amount.toStringAsFixed(0)
          : tx.amount.toStringAsFixed(2),
    );
    final formKey = GlobalKey<FormState>();
    TxCategory? cat = tx.category;

    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) {
        final dc = ctx.appColors;
        return StatefulBuilder(
          builder: (ctx, setDlg) => AlertDialog(
            backgroundColor: dc.card,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(8),
            ),
            title: Text(
              'Edit',
              style: TextStyle(
                color: dc.textPrimary,
                fontSize: 16,
                fontWeight: FontWeight.w500,
              ),
            ),
            content: Form(
              key: formKey,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _DialogField(
                    controller: titleCtrl,
                    label: 'Title',
                    validator: (v) =>
                        (v == null || v.trim().isEmpty) ? 'Required' : null,
                  ),
                  const SizedBox(height: 12),
                  _DialogField(
                    controller: amountCtrl,
                    label: 'Amount',
                    keyboardType: const TextInputType.numberWithOptions(
                      decimal: true,
                    ),
                    validator: (v) {
                      final p = double.tryParse((v ?? '').replaceAll(',', '.'));
                      return (p == null || p <= 0)
                          ? 'Enter valid amount'
                          : null;
                    },
                  ),
                  if (!tx.isCredit) ...[
                    const SizedBox(height: 16),
                    Text(
                      'CATEGORY',
                      style: TextStyle(
                        color: dc.textSecondary,
                        fontSize: 10,
                        letterSpacing: 0.8,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: TxCategory.values.map((c) {
                        final sel = cat == c;
                        return GestureDetector(
                          onTap: () => setDlg(() => cat = c),
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 12,
                              vertical: 7,
                            ),
                            decoration: BoxDecoration(
                              color: sel
                                  ? dc.negativeText.withValues(alpha: 0.15)
                                  : dc.surface,
                              borderRadius: BorderRadius.circular(20),
                              border: Border.all(
                                color: sel
                                    ? dc.negativeText.withValues(alpha: 0.5)
                                    : dc.border,
                              ),
                            ),
                            child: Text(
                              c.label,
                              style: TextStyle(
                                color: sel ? dc.negativeText : dc.textSecondary,
                                fontSize: 12,
                              ),
                            ),
                          ),
                        );
                      }).toList(),
                    ),
                  ],
                ],
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(ctx).pop(false),
                child: Text(
                  'Cancel',
                  style: TextStyle(color: dc.textSecondary),
                ),
              ),
              TextButton(
                onPressed: () {
                  if (formKey.currentState?.validate() ?? false) {
                    Navigator.of(ctx).pop(true);
                  }
                },
                child: Text(
                  'Save',
                  style: TextStyle(
                    color: dc.positiveText,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );

    if (ok == true && mounted) {
      final amount = double.parse(amountCtrl.text.replaceAll(',', '.'));
      await widget.updateTransaction(
        FinanceTransaction(
          id: tx.id,
          date: tx.date,
          title: titleCtrl.text.trim(),
          amount: amount,
          isCredit: tx.isCredit,
          category: tx.isCredit ? null : cat,
        ),
      );
      widget.onTxChanged();
    }
  }

  Future<void> _deleteTx(FinanceTransaction tx) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) {
        final dc = ctx.appColors;
        return AlertDialog(
          backgroundColor: dc.card,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
          title: Text(
            'Delete',
            style: TextStyle(
              color: dc.textPrimary,
              fontSize: 16,
              fontWeight: FontWeight.w500,
            ),
          ),
          content: Text(
            'Delete "${tx.title}"?',
            style: TextStyle(color: dc.textSecondary, fontSize: 14),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(ctx).pop(false),
              child: Text('Cancel', style: TextStyle(color: dc.textSecondary)),
            ),
            TextButton(
              onPressed: () => Navigator.of(ctx).pop(true),
              child: Text(
                'Delete',
                style: TextStyle(
                  color: dc.negativeText,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ],
        );
      },
    );
    if (ok == true && mounted) {
      await widget.deleteTransaction(tx.id);
      widget.onTxChanged();
    }
  }

  bool _isSameDay(DateTime a, DateTime b) =>
      a.year == b.year && a.month == b.month && a.day == b.day;

  double _sum(Iterable<FinanceTransaction> txs) =>
      txs.fold<double>(0, (s, tx) => s + tx.amount);

  String _money(double v) => v == v.roundToDouble()
      ? '₺${v.toStringAsFixed(0)}'
      : '₺${v.toStringAsFixed(2)}';

  String _weekLabel(DateTime start) {
    final end = start.add(const Duration(days: 6));
    const m = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec',
    ];
    if (start.month == end.month) {
      return '${start.day}–${end.day} ${m[start.month - 1]} ${start.year}';
    }
    return '${start.day} ${m[start.month - 1]} – ${end.day} ${m[end.month - 1]} ${start.year}';
  }
}

// ── Arrow button ─────────────────────────────────────────────────────────────

class _ArrowBtn extends StatelessWidget {
  const _ArrowBtn({required this.icon, required this.onTap});
  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final c = context.appColors;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 32,
        height: 32,
        decoration: BoxDecoration(
          color: c.card,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: c.border, width: 0.5),
        ),
        child: Icon(icon, color: c.textSecondary, size: 18),
      ),
    );
  }
}

// ── Stat item ────────────────────────────────────────────────────────────────

class _StatItem extends StatelessWidget {
  const _StatItem({
    required this.label,
    required this.value,
    required this.color,
  });
  final String label;
  final String value;
  final Color color;

  @override
  Widget build(BuildContext context) {
    final c = context.appColors;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            color: c.textSecondary,
            fontSize: 9,
            letterSpacing: 0.8,
            fontWeight: FontWeight.w500,
          ),
        ),
        const SizedBox(height: 6),
        Text(
          value,
          style: TextStyle(
            color: color,
            fontSize: 22,
            fontWeight: FontWeight.w600,
            letterSpacing: -0.5,
          ),
        ),
      ],
    );
  }
}

// ── Gün satırı ───────────────────────────────────────────────────────────────

class _DayRow extends StatelessWidget {
  const _DayRow({
    required this.date,
    required this.txs,
    required this.isSelected,
  });
  final DateTime date;
  final List<FinanceTransaction> txs;
  final bool isSelected;

  @override
  Widget build(BuildContext context) {
    final c = context.appColors;
    const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    final income = txs
        .where((e) => e.isCredit)
        .fold<double>(0, (s, t) => s + t.amount);
    final expense = txs
        .where((e) => !e.isCredit)
        .fold<double>(0, (s, t) => s + t.amount);
    final net = income - expense;
    final hasData = income > 0 || expense > 0;
    final lineColor = !hasData
        ? c.border
        : net >= 0
        ? c.positiveText
        : c.negativeText;
    final netStr = net == 0
        ? '—'
        : net > 0
        ? '+₺${net.toStringAsFixed(net == net.roundToDouble() ? 0 : 2)}'
        : '−₺${net.abs().toStringAsFixed(net.abs() == net.abs().roundToDouble() ? 0 : 2)}';

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Row(
        children: [
          SizedBox(
            width: 32,
            child: Text(
              dayNames[date.weekday % 7],
              style: TextStyle(
                color: c.textSecondary,
                fontWeight: FontWeight.w400,
                fontSize: 13,
              ),
            ),
          ),
          SizedBox(
            width: 28,
            child: Text(
              '${date.day}',
              style: TextStyle(
                color: c.textSecondary,
                fontWeight: FontWeight.w400,
                fontSize: 13,
              ),
            ),
          ),
          Expanded(
            child: _NetBar(
              hasData: hasData,
              isPositive: net >= 0,
              color: lineColor,
              bgColor: c.border,
            ),
          ),
          const SizedBox(width: 12),
          SizedBox(
            width: 70,
            child: Text(
              netStr,
              textAlign: TextAlign.right,
              style: TextStyle(
                color: !hasData
                    ? c.textMuted
                    : net >= 0
                    ? c.positiveText
                    : c.negativeText,
                fontSize: 13,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ── Net bar ──────────────────────────────────────────────────────────────────

class _NetBar extends StatelessWidget {
  const _NetBar({
    required this.hasData,
    required this.isPositive,
    required this.color,
    required this.bgColor,
  });
  final bool hasData;
  final bool isPositive;
  final Color color;
  final Color bgColor;

  @override
  Widget build(BuildContext context) => SizedBox(
    height: 16,
    child: CustomPaint(
      painter: _NetBarPainter(
        hasData: hasData,
        isPositive: isPositive,
        activeColor: color,
        bgColor: bgColor,
      ),
    ),
  );
}

class _NetBarPainter extends CustomPainter {
  _NetBarPainter({
    required this.hasData,
    required this.isPositive,
    required this.activeColor,
    required this.bgColor,
  });
  final bool hasData, isPositive;
  final Color activeColor, bgColor;

  @override
  void paint(Canvas canvas, Size size) {
    final cy = size.height / 2;
    canvas.drawLine(
      Offset(0, cy),
      Offset(size.width, cy),
      Paint()
        ..color = bgColor
        ..strokeWidth = 1
        ..strokeCap = StrokeCap.round,
    );
    if (!hasData) return;
    final w = size.width * 0.65;
    final p = Paint()
      ..color = activeColor
      ..strokeWidth = 2
      ..strokeCap = StrokeCap.round;
    if (isPositive) {
      canvas.drawLine(Offset(0, cy), Offset(w, cy), p);
    } else {
      canvas.drawLine(Offset(size.width - w, cy), Offset(size.width, cy), p);
    }
  }

  @override
  bool shouldRepaint(_NetBarPainter old) =>
      old.hasData != hasData ||
      old.isPositive != isPositive ||
      old.activeColor != activeColor;
}

// ── Gün bölümü ───────────────────────────────────────────────────────────────

class _DaySection extends StatelessWidget {
  const _DaySection({
    required this.date,
    required this.transactions,
    required this.money,
    required this.isToday,
    required this.onEdit,
    required this.onDelete,
  });
  final DateTime date;
  final List<FinanceTransaction> transactions;
  final String Function(double) money;
  final bool isToday;
  final ValueChanged<FinanceTransaction> onEdit;
  final ValueChanged<FinanceTransaction> onDelete;

  @override
  Widget build(BuildContext context) {
    final c = context.appColors;
    const months = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec',
    ];
    final label = isToday
        ? 'Today, ${date.day} ${months[date.month - 1]}'
        : '${_dayName(date.weekday)}, ${date.day} ${months[date.month - 1]}';

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              label,
              style: TextStyle(
                color: c.textSecondary,
                fontSize: 11,
                fontWeight: FontWeight.w500,
                letterSpacing: 0.5,
              ),
            ),
            Text(
              '${transactions.length} tx',
              style: TextStyle(color: c.textMuted, fontSize: 10),
            ),
          ],
        ),
        const SizedBox(height: 12),
        Container(
          decoration: BoxDecoration(
            color: c.card,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: c.border, width: 0.5),
          ),
          child: Column(
            children: [
              for (int i = 0; i < transactions.length; i++) ...[
                _TxRow(
                  tx: transactions[i],
                  money: money,
                  onEdit: onEdit,
                  onDelete: onDelete,
                ),
                if (i < transactions.length - 1)
                  Divider(
                    height: 1,
                    indent: 14,
                    endIndent: 14,
                    color: c.border,
                  ),
              ],
            ],
          ),
        ),
      ],
    );
  }

  String _dayName(int w) =>
      const ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'][w - 1];
}

// ── İşlem satırı ─────────────────────────────────────────────────────────────

class _TxRow extends StatelessWidget {
  const _TxRow({
    required this.tx,
    required this.money,
    required this.onEdit,
    required this.onDelete,
  });
  final FinanceTransaction tx;
  final String Function(double) money;
  final ValueChanged<FinanceTransaction> onEdit;
  final ValueChanged<FinanceTransaction> onDelete;

  @override
  Widget build(BuildContext context) {
    final c = context.appColors;
    final color = tx.isCredit ? c.positiveText : c.negativeText;
    return GestureDetector(
      onLongPress: () => _showMenu(context),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
        child: Row(
          children: [
            Expanded(
              child: Text(
                tx.title,
                style: TextStyle(
                  color: c.textPrimary,
                  fontSize: 14,
                  fontWeight: FontWeight.w400,
                ),
              ),
            ),
            Text(
              '${tx.isCredit ? '+' : '−'}${money(tx.amount)}',
              style: TextStyle(
                color: color,
                fontSize: 14,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showMenu(BuildContext context) {
    final c = context.appColors;
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: c.card,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (sheetCtx) {
        final sc = sheetCtx.appColors;
        return SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const SizedBox(height: 8),
              Container(
                width: 36,
                height: 4,
                decoration: BoxDecoration(
                  color: sc.border,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              const SizedBox(height: 16),
              ListTile(
                leading: Icon(
                  Icons.edit_outlined,
                  color: sc.textSecondary,
                  size: 20,
                ),
                title: Text(
                  'Edit',
                  style: TextStyle(color: sc.textPrimary, fontSize: 14),
                ),
                onTap: () {
                  Navigator.of(sheetCtx).pop();
                  onEdit(tx);
                },
              ),
              ListTile(
                leading: Icon(
                  Icons.delete_outline,
                  color: sc.negativeText,
                  size: 20,
                ),
                title: Text(
                  'Delete',
                  style: TextStyle(color: sc.negativeText, fontSize: 14),
                ),
                onTap: () {
                  Navigator.of(sheetCtx).pop();
                  onDelete(tx);
                },
              ),
              const SizedBox(height: 8),
            ],
          ),
        );
      },
    );
  }
}

// ── Dialog field ─────────────────────────────────────────────────────────────

class _DialogField extends StatelessWidget {
  const _DialogField({
    required this.controller,
    required this.label,
    this.keyboardType,
    this.validator,
  });
  final TextEditingController controller;
  final String label;
  final TextInputType? keyboardType;
  final String? Function(String?)? validator;

  @override
  Widget build(BuildContext context) {
    final c = context.appColors;
    return TextFormField(
      controller: controller,
      keyboardType: keyboardType,
      validator: validator,
      style: TextStyle(color: c.textPrimary, fontSize: 14),
      decoration: InputDecoration(
        filled: false,
        fillColor: Colors.transparent,
        contentPadding: const EdgeInsets.symmetric(vertical: 8),
        labelText: label,
        labelStyle: TextStyle(color: c.textSecondary, fontSize: 13),
        border: UnderlineInputBorder(borderSide: BorderSide(color: c.border)),
        enabledBorder: UnderlineInputBorder(
          borderSide: BorderSide(color: c.border),
        ),
        focusedBorder: UnderlineInputBorder(
          borderSide: BorderSide(color: c.positiveText, width: 1),
        ),
      ),
    );
  }
}

// ── Nav Item ─────────────────────────────────────────────────────────────────

class _NavItem extends StatelessWidget {
  const _NavItem({
    required this.icon,
    required this.label,
    required this.isActive,
    required this.color,
  });

  final IconData icon;
  final String label;
  final bool isActive;
  final dynamic color;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(
          icon,
          color: isActive ? color.positiveText : color.textSecondary,
          size: 24,
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: TextStyle(
            color: isActive ? color.textPrimary : color.textSecondary,
            fontSize: 11,
            fontWeight: isActive ? FontWeight.w600 : FontWeight.w400,
          ),
        ),
      ],
    );
  }
}
