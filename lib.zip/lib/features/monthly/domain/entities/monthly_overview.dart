class MonthlyOverview {
  const MonthlyOverview({
    required this.monthLabel,
    required this.totalCredit,
    required this.totalCost,
    required this.todayCredit,
    required this.todayCostItems,
    required this.weeklyCredit,
    required this.weeklyCost,
  });

  final String monthLabel;
  final String totalCredit;
  final String totalCost;
  final String todayCredit;
  final List<String> todayCostItems;
  final String weeklyCredit;
  final String weeklyCost;
}
