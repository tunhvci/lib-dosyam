import 'package:no_name/features/monthly/domain/entities/monthly_overview.dart';
import 'package:no_name/features/monthly/domain/repositories/monthly_repository.dart';

class GetMonthlyOverview {
  const GetMonthlyOverview(this._repository);

  final MonthlyRepository _repository;

  Future<MonthlyOverview> call() {
    return _repository.getMonthlyOverview();
  }
}
