import 'package:no_name/features/monthly/domain/entities/monthly_overview.dart';

abstract class MonthlyRepository {
  Future<MonthlyOverview> getMonthlyOverview();
}
