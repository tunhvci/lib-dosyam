import 'package:no_name/features/monthly/domain/entities/monthly_overview.dart';
import 'package:no_name/features/monthly/domain/repositories/monthly_repository.dart';

class MonthlyRepositoryImpl implements MonthlyRepository {
  @override
  Future<MonthlyOverview> getMonthlyOverview() async {
    return const MonthlyOverview(
      monthLabel: 'September 2026',
      totalCredit: '₺4.200',
      totalCost: '₺2.850',
      todayCredit: '₺3.500',
      todayCostItems: ['Food - ₺85', 'Transport - ₺32'],
      weeklyCredit: '₺3.500',
      weeklyCost: '₺680',
    );
  }
}
