import 'package:no_name/features/transactions/domain/entities/finance_transaction.dart';
import 'package:no_name/features/transactions/domain/repositories/transaction_repository.dart';

class InMemoryTransactionRepository implements TransactionRepository {
  final List<FinanceTransaction> _transactions = [];

  @override
  Future<void> addTransaction(FinanceTransaction transaction) async {
    _transactions.add(transaction);
  }

  @override
  Future<void> updateTransaction(FinanceTransaction transaction) async {
    final index = _transactions.indexWhere((item) => item.id == transaction.id);
    if (index != -1) {
      _transactions[index] = transaction;
    }
  }

  @override
  Future<void> deleteTransaction(String id) async {
    _transactions.removeWhere((item) => item.id == id);
  }

  @override
  List<FinanceTransaction> getAllTransactions() {
    return List<FinanceTransaction>.unmodifiable(_transactions);
  }

  @override
  List<FinanceTransaction> getTransactionsByDate(DateTime date) {
    return _transactions
        .where(
          (item) =>
              item.date.year == date.year &&
              item.date.month == date.month &&
              item.date.day == date.day,
        )
        .toList(growable: false);
  }
}
