import 'dart:convert';

import 'package:no_name/features/transactions/domain/entities/finance_transaction.dart';
import 'package:no_name/features/transactions/domain/repositories/transaction_repository.dart';
import 'package:shared_preferences/shared_preferences.dart';

class PersistentTransactionRepository implements TransactionRepository {
  static const _key = 'transactions_v2';

  final List<FinanceTransaction> _cache = [];
  bool _loaded = false;

  Future<void> load() async {
    if (_loaded) return;
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList(_key) ?? [];
    _cache
      ..clear()
      ..addAll(raw.map(_fromJson));
    _loaded = true;
  }

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(_key, _cache.map(_toJson).toList());
  }

  @override
  Future<void> addTransaction(FinanceTransaction tx) async {
    _cache.add(tx);
    await _save();
  }

  @override
  Future<void> updateTransaction(FinanceTransaction tx) async {
    final i = _cache.indexWhere((e) => e.id == tx.id);
    if (i != -1) {
      _cache[i] = tx;
      await _save();
    }
  }

  @override
  Future<void> deleteTransaction(String id) async {
    _cache.removeWhere((e) => e.id == id);
    await _save();
  }

  @override
  List<FinanceTransaction> getAllTransactions() =>
      List<FinanceTransaction>.unmodifiable(_cache);

  @override
  List<FinanceTransaction> getTransactionsByDate(DateTime date) => _cache
      .where(
        (tx) =>
            tx.date.year == date.year &&
            tx.date.month == date.month &&
            tx.date.day == date.day,
      )
      .toList(growable: false);

  static String _toJson(FinanceTransaction tx) => jsonEncode({
    'id': tx.id,
    'date': tx.date.toIso8601String(),
    'title': tx.title,
    'amount': tx.amount,
    'isCredit': tx.isCredit,
    'category': tx.category?.name,
  });

  static FinanceTransaction _fromJson(String raw) {
    final m = jsonDecode(raw) as Map<String, dynamic>;
    final catStr = m['category'] as String?;
    final cat = catStr == null
        ? null
        : TxCategory.values.where((e) => e.name == catStr).firstOrNull;
    return FinanceTransaction(
      id: m['id'] as String,
      date: DateTime.parse(m['date'] as String),
      title: m['title'] as String,
      amount: (m['amount'] as num).toDouble(),
      isCredit: m['isCredit'] as bool,
      category: cat,
    );
  }
}
