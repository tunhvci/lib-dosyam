enum TxCategory {
  rent,
  bills,
  food,
  transport,
  health,
  shopping,
  personalCare,
  extra,
}

extension TxCategoryLabel on TxCategory {
  String get label {
    switch (this) {
      case TxCategory.rent:
        return 'Kira';
      case TxCategory.bills:
        return 'Faturalar';
      case TxCategory.food:
        return 'Yemek';
      case TxCategory.transport:
        return 'Ulasim';
      case TxCategory.health:
        return 'Saglik';
      case TxCategory.shopping:
        return 'Alisveris';
      case TxCategory.personalCare:
        return 'Kisisel Bakim';
      case TxCategory.extra:
        return 'Ekstra';
    }
  }
}

class FinanceTransaction {
  const FinanceTransaction({
    required this.id,
    required this.date,
    required this.title,
    required this.amount,
    required this.isCredit,
    this.category,
  });

  final String id;
  final DateTime date;
  final String title;
  final double amount;
  final bool isCredit;
  final TxCategory? category; // only for expenses
}
