import 'package:no_name/features/transactions/domain/entities/finance_transaction.dart';
import 'package:no_name/features/transactions/domain/repositories/transaction_repository.dart';

class UpdateTransaction {
  const UpdateTransaction(this._repository);
  final TransactionRepository _repository;
  Future<void> call(FinanceTransaction tx) => _repository.updateTransaction(tx);
}
