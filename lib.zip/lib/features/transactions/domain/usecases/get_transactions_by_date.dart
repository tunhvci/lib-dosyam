import 'package:no_name/features/transactions/domain/entities/finance_transaction.dart';
import 'package:no_name/features/transactions/domain/repositories/transaction_repository.dart';

class GetTransactionsByDate {
  const GetTransactionsByDate(this._repository);

  final TransactionRepository _repository;

  List<FinanceTransaction> call(DateTime date) {
    return _repository.getTransactionsByDate(date);
  }
}
