import 'package:no_name/features/transactions/domain/entities/finance_transaction.dart';

abstract class TransactionRepository {
  List<FinanceTransaction> getTransactionsByDate(DateTime date);
  List<FinanceTransaction> getAllTransactions();
  Future<void> addTransaction(FinanceTransaction transaction);
  Future<void> updateTransaction(FinanceTransaction transaction);
  Future<void> deleteTransaction(String id);
}
