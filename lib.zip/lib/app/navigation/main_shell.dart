import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:no_name/core/theme/app_colors.dart';
import 'package:no_name/core/theme/app_theme.dart';
import 'package:no_name/features/charts/presentation/pages/charts_page.dart';
import 'package:no_name/features/daily/presentation/pages/daily_page.dart';
import 'package:no_name/features/goals/presentation/pages/goals_page.dart';
import 'package:no_name/features/home/presentation/pages/home_page.dart';
import 'package:no_name/features/monthly/presentation/pages/monthly_page.dart';
import 'package:no_name/features/transactions/data/repositories/persistent_transaction_repository.dart';
import 'package:no_name/features/transactions/domain/usecases/add_transaction.dart';
import 'package:no_name/features/transactions/domain/usecases/delete_transaction.dart';
import 'package:no_name/features/transactions/domain/usecases/get_all_transactions.dart';
import 'package:no_name/features/transactions/domain/usecases/get_transactions_by_date.dart';
import 'package:no_name/features/transactions/domain/usecases/update_transaction.dart';
import 'package:no_name/features/weekly/presentation/pages/weekly_page.dart';

class MainShell extends StatefulWidget {
  const MainShell({
    required this.transactionRepository,
    required this.currentThemeListenable,
    required this.onThemeSelected,
    super.key,
  });

  final PersistentTransactionRepository transactionRepository;
  final ValueListenable<AppThemePreset> currentThemeListenable;
  final ValueChanged<AppThemePreset> onThemeSelected;

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell>
    with SingleTickerProviderStateMixin {
  int _currentIndex = 0;
  int _previousIndex = 0;
  final ValueNotifier<DateTime> _selectedDate = ValueNotifier<DateTime>(
    DateTime.now(),
  );
  final ValueNotifier<int> _txVersion = ValueNotifier<int>(0);

  PersistentTransactionRepository get _repo => widget.transactionRepository;

  late final List<Widget> _pages = [
    HomePage(
      addTransaction: AddTransaction(_repo),
      onTransactionAdded: () => _txVersion.value++,
    ),
    MonthlyPage(
      addTransaction: AddTransaction(_repo),
      updateTransaction: UpdateTransaction(_repo),
      deleteTransaction: DeleteTransaction(_repo),
      getAllTransactions: GetAllTransactions(_repo),
      getTransactionsByDate: GetTransactionsByDate(_repo),
      selectedDateListenable: _selectedDate,
      txVersionListenable: _txVersion,
      onTransactionAdded: () => _txVersion.value++,
    ),
    WeeklyPage(
      selectedDateListenable: _selectedDate,
      txVersionListenable: _txVersion,
      getTransactionsByDate: GetTransactionsByDate(_repo),
      updateTransaction: UpdateTransaction(_repo),
      deleteTransaction: DeleteTransaction(_repo),
      onTxChanged: () => _txVersion.value++,
    ),
    DailyPage(
      selectedDateListenable: _selectedDate,
      txVersionListenable: _txVersion,
      getTransactionsByDate: GetTransactionsByDate(_repo),
      onDateChanged: (date) => _selectedDate.value = date,
    ),
    ChartsPage(
      getAllTransactions: GetAllTransactions(_repo),
      txVersionListenable: _txVersion,
    ),
  ];

  @override
  void dispose() {
    _selectedDate.dispose();
    _txVersion.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppThemePreset>(
      valueListenable: widget.currentThemeListenable,
      builder: (context, activeTheme, _) {
        return Scaffold(
          appBar: AppBar(
            toolbarHeight: 42,
            backgroundColor: Colors.transparent,
            elevation: 0,
            actions: [
              IconButton(
                tooltip: 'Goals',
                onPressed: () => _openGoalsPage(context),
                icon: const Icon(Icons.flag_outlined),
              ),
              IconButton(
                tooltip: 'Tema',
                onPressed: () => _openThemePicker(context, activeTheme),
                icon: const Icon(Icons.palette_rounded),
              ),
            ],
          ),
          body: SafeArea(
            top: false,
            child: RepaintBoundary(
              child: AnimatedSwitcher(
                duration: const Duration(milliseconds: 220),
                switchInCurve: Curves.easeInOutCubic,
                switchOutCurve: Curves.easeInOutCubic,
                transitionBuilder: (child, animation) {
                  final isForward = _currentIndex >= _previousIndex;
                  final begin = Offset(isForward ? 0.03 : -0.03, 0);
                  return FadeTransition(
                    opacity: animation,
                    child: SlideTransition(
                      position: Tween<Offset>(begin: begin, end: Offset.zero)
                          .animate(
                            CurvedAnimation(
                              parent: animation,
                              curve: Curves.easeInOutCubic,
                            ),
                          ),
                      child: child,
                    ),
                  );
                },
                child: KeyedSubtree(
                  key: ValueKey<int>(_currentIndex),
                  child: _pages[_currentIndex],
                ),
              ),
            ),
          ),
          bottomNavigationBar: _BottomNav(
            currentIndex: _currentIndex,
            onTap: (index) => setState(() {
              _previousIndex = _currentIndex;
              _currentIndex = index;
            }),
          ),
        );
      },
    );
  }

  Future<void> _openGoalsPage(BuildContext context) async {
    await Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (context) =>
            GoalsPage(getAllTransactions: GetAllTransactions(_repo)),
      ),
    );
  }

  Future<void> _openThemePicker(
    BuildContext context,
    AppThemePreset currentTheme,
  ) async {
    final c = context.appColors;
    final next = await showModalBottomSheet<AppThemePreset>(
      context: context,
      backgroundColor: c.card,
      showDragHandle: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (sheetCtx) {
        final sc = sheetCtx.appColors;
        return SafeArea(
          child: ListView(
            shrinkWrap: true,
            padding: const EdgeInsets.fromLTRB(8, 4, 8, 12),
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(12, 6, 12, 10),
                child: Text(
                  'Tema seç',
                  style: TextStyle(
                    color: sc.textPrimary,
                    fontSize: 15,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
              ...AppThemePreset.values.map(
                (preset) => ListTile(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                  leading: Icon(
                    _themeIcon(preset),
                    color: preset == currentTheme
                        ? sc.positiveText
                        : sc.textSecondary,
                  ),
                  title: Text(
                    preset.label,
                    style: TextStyle(fontSize: 14, color: sc.textPrimary),
                  ),
                  subtitle: Padding(
                    padding: const EdgeInsets.only(top: 6),
                    child: Row(
                      children: preset.previewColors
                          .map(
                            (color) => Container(
                              width: 14,
                              height: 14,
                              margin: const EdgeInsets.only(right: 6),
                              decoration: BoxDecoration(
                                color: color,
                                shape: BoxShape.circle,
                                border: Border.all(
                                  color: sc.border.withValues(alpha: 0.7),
                                  width: 0.6,
                                ),
                              ),
                            ),
                          )
                          .toList(growable: false),
                    ),
                  ),
                  trailing: preset == currentTheme
                      ? Icon(Icons.check_rounded, color: sc.positiveText)
                      : null,
                  onTap: () => Navigator.of(sheetCtx).pop(preset),
                ),
              ),
            ],
          ),
        );
      },
    );
    if (next != null && next != currentTheme) {
      widget.onThemeSelected(next);
    }
  }

  IconData _themeIcon(AppThemePreset preset) {
    switch (preset) {
      case AppThemePreset.midnightBlue:
        return Icons.nightlight_round;
      case AppThemePreset.twilight:
        return Icons.brightness_3_rounded;
      case AppThemePreset.sunrise:
        return Icons.wb_sunny_rounded;
      case AppThemePreset.darkClassic:
        return Icons.dark_mode_rounded;
    }
  }
}

// ── Custom bottom nav ────────────────────────────────────────────────────────

class _BottomNav extends StatelessWidget {
  const _BottomNav({required this.currentIndex, required this.onTap});

  final int currentIndex;
  final ValueChanged<int> onTap;

  @override
  Widget build(BuildContext context) {
    final c = context.appColors;
    return SafeArea(
      top: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(10, 0, 10, 10),
        child: Container(
          height: 68,
          decoration: BoxDecoration(
            color: c.surface.withValues(alpha: 0.96),
            borderRadius: BorderRadius.circular(8),
            border: Border.all(
              color: c.border.withValues(alpha: 0.8),
              width: 0.8,
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.14),
                blurRadius: 18,
                offset: const Offset(0, 6),
              ),
            ],
          ),
          child: Row(
            children: [
              _NavItem(
                index: 0,
                currentIndex: currentIndex,
                label: 'Home',
                icon: Icon(
                  Icons.home_rounded,
                  size: 20,
                  color: currentIndex == 0 ? c.textPrimary : c.textSecondary,
                ),
                onTap: onTap,
              ),
              _NavItem(
                index: 1,
                currentIndex: currentIndex,
                label: 'Monthly',
                icon: _MonthlyIcon(selected: currentIndex == 1),
                onTap: onTap,
              ),
              _NavItem(
                index: 2,
                currentIndex: currentIndex,
                label: 'Weekly',
                icon: _WeeklyIcon(selected: currentIndex == 2),
                onTap: onTap,
              ),
              _NavItem(
                index: 3,
                currentIndex: currentIndex,
                label: 'Daily',
                icon: _DailyIcon(selected: currentIndex == 3),
                onTap: onTap,
              ),
              _NavItem(
                index: 4,
                currentIndex: currentIndex,
                label: 'Charts',
                icon: Icon(
                  Icons.pie_chart_rounded,
                  size: 18,
                  color: currentIndex == 4 ? c.textPrimary : c.textSecondary,
                ),
                onTap: onTap,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _NavItem extends StatelessWidget {
  const _NavItem({
    required this.index,
    required this.currentIndex,
    required this.label,
    required this.icon,
    required this.onTap,
  });

  final int index;
  final int currentIndex;
  final String label;
  final Widget icon;
  final ValueChanged<int> onTap;

  @override
  Widget build(BuildContext context) {
    final c = context.appColors;
    final selected = index == currentIndex;
    return Expanded(
      child: InkWell(
        onTap: () => onTap(index),
        borderRadius: BorderRadius.circular(6),
        child: Container(
          margin: const EdgeInsets.symmetric(horizontal: 3, vertical: 5),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(6),
            color: selected
                ? c.overlay.withValues(alpha: 0.6)
                : Colors.transparent,
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              icon,
              const SizedBox(height: 4),
              Text(
                label,
                style: TextStyle(
                  fontSize: 11,
                  fontWeight: selected ? FontWeight.w600 : FontWeight.w500,
                  color: selected ? c.textPrimary : c.textSecondary,
                  letterSpacing: 0.2,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// Monthly icon — 2×2 grid of rounded squares
class _MonthlyIcon extends StatelessWidget {
  const _MonthlyIcon({required this.selected});
  final bool selected;

  @override
  Widget build(BuildContext context) {
    final c = context.appColors;
    final color = selected ? c.textPrimary : c.textSecondary;
    const sz = 7.0;
    const gap = 3.0;
    return SizedBox(
      width: sz * 2 + gap,
      height: sz * 2 + gap,
      child: Column(
        children: [
          Row(
            children: [
              _Sq(size: sz, color: color),
              const SizedBox(width: gap),
              _Sq(size: sz, color: color),
            ],
          ),
          const SizedBox(height: gap),
          Row(
            children: [
              _Sq(size: sz, color: color),
              const SizedBox(width: gap),
              _Sq(size: sz, color: color),
            ],
          ),
        ],
      ),
    );
  }
}

class _Sq extends StatelessWidget {
  const _Sq({required this.size, required this.color});
  final double size;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(2),
      ),
    );
  }
}

// Weekly icon — 3 vertical bars
class _WeeklyIcon extends StatelessWidget {
  const _WeeklyIcon({required this.selected});
  final bool selected;

  @override
  Widget build(BuildContext context) {
    final c = context.appColors;
    final color = selected ? c.textPrimary : c.textSecondary;
    return Row(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        _Bar(width: 5, height: 14, color: color),
        const SizedBox(width: 3),
        _Bar(width: 5, height: 18, color: color),
        const SizedBox(width: 3),
        _Bar(width: 5, height: 14, color: color),
      ],
    );
  }
}

class _Bar extends StatelessWidget {
  const _Bar({required this.width, required this.height, required this.color});
  final double width;
  final double height;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: width,
      height: height,
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(2),
      ),
    );
  }
}

// Daily icon — 3 horizontal lines
class _DailyIcon extends StatelessWidget {
  const _DailyIcon({required this.selected});
  final bool selected;

  @override
  Widget build(BuildContext context) {
    final c = context.appColors;
    final color = selected ? c.textPrimary : c.textSecondary;
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _Line(width: 18, color: color),
        const SizedBox(height: 4),
        _Line(width: 14, color: color),
        const SizedBox(height: 4),
        _Line(width: 18, color: color),
      ],
    );
  }
}

class _Line extends StatelessWidget {
  const _Line({required this.width, required this.color});
  final double width;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: width,
      height: 2,
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(1),
      ),
    );
  }
}
