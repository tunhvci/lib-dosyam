import 'package:flutter/material.dart';
import 'package:no_name/app/navigation/main_shell.dart';
import 'package:no_name/core/theme/app_theme.dart';
import 'package:no_name/features/splash/data/repositories/app_startup_repository_impl.dart';
import 'package:no_name/features/splash/domain/usecases/get_startup_delay.dart';
import 'package:no_name/features/splash/presentation/pages/splash_page.dart';
import 'package:no_name/features/transactions/data/repositories/persistent_transaction_repository.dart';

class NoNameApp extends StatefulWidget {
  const NoNameApp({required this.transactionRepository, super.key});

  final PersistentTransactionRepository transactionRepository;

  @override
  State<NoNameApp> createState() => _NoNameAppState();
}

class _NoNameAppState extends State<NoNameApp> {
  final ValueNotifier<AppThemePreset> _themePreset =
      ValueNotifier<AppThemePreset>(AppThemePreset.darkClassic);

  @override
  void dispose() {
    _themePreset.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppThemePreset>(
      valueListenable: _themePreset,
      builder: (context, preset, _) => MaterialApp(
        debugShowCheckedModeBanner: false,
        theme: AppTheme.themeFor(preset),
        themeAnimationDuration: const Duration(milliseconds: 250),
        themeAnimationCurve: Curves.easeInOutCubic,
        builder: (context, child) => _ThemeVisualLayer(
          preset: preset,
          child: child ?? const SizedBox.shrink(),
        ),
        home: Builder(
          builder: (navigatorContext) => SplashPage(
            getStartupDelay: GetStartupDelay(AppStartupRepositoryImpl()),
            onCompleted: () {
              Navigator.of(navigatorContext).pushReplacement(
                MaterialPageRoute<void>(
                  builder: (_) => MainShell(
                    transactionRepository: widget.transactionRepository,
                    currentThemeListenable: _themePreset,
                    onThemeSelected: (nextPreset) =>
                        _themePreset.value = nextPreset,
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}

class _ThemeVisualLayer extends StatelessWidget {
  const _ThemeVisualLayer({required this.preset, required this.child});

  final AppThemePreset preset;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    final fx = _themeFx(preset);
    if (fx == null) return child;

    return ColorFiltered(
      colorFilter: ColorFilter.mode(fx.tint, fx.blendMode),
      child: Stack(
        fit: StackFit.expand,
        children: [
          child,
          IgnorePointer(
            child: DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    fx.gradientA.withValues(alpha: fx.gradientAlphaA),
                    fx.gradientB.withValues(alpha: fx.gradientAlphaB),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  _ThemeFx? _themeFx(AppThemePreset preset) {
    switch (preset) {
      case AppThemePreset.midnightBlue:
        return const _ThemeFx(
          tint: Color(0xFF8FC0FF),
          blendMode: BlendMode.softLight,
          gradientA: Color(0xFF0B2A52),
          gradientB: Color(0xFF193E73),
          gradientAlphaA: 0.07,
          gradientAlphaB: 0.04,
        );
      case AppThemePreset.twilight:
        return const _ThemeFx(
          tint: Color(0xFFC8A6FF),
          blendMode: BlendMode.softLight,
          gradientA: Color(0xFF332152),
          gradientB: Color(0xFF4E2F69),
          gradientAlphaA: 0.07,
          gradientAlphaB: 0.05,
        );
      case AppThemePreset.sunrise:
        return const _ThemeFx(
          tint: Color(0xFFFFE4B9),
          blendMode: BlendMode.softLight,
          gradientA: Color(0xFFFFF4DE),
          gradientB: Color(0xFFFFEFD1),
          gradientAlphaA: 0.05,
          gradientAlphaB: 0.03,
        );
      case AppThemePreset.darkClassic:
        return null;
    }
  }
}

class _ThemeFx {
  const _ThemeFx({
    required this.tint,
    required this.blendMode,
    required this.gradientA,
    required this.gradientB,
    required this.gradientAlphaA,
    required this.gradientAlphaB,
  });

  final Color tint;
  final BlendMode blendMode;
  final Color gradientA;
  final Color gradientB;
  final double gradientAlphaA;
  final double gradientAlphaB;
}
