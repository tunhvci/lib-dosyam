import 'package:flutter/material.dart';

/// Tema-aware renk seti. Her tema kendi [AppThemeColors] örneğini
/// ThemeExtension olarak taşır; widget'lar [context.appColors] ile erişir.
class AppThemeColors extends ThemeExtension<AppThemeColors> {
  const AppThemeColors({
    required this.background,
    required this.surface,
    required this.card,
    required this.border,
    required this.overlay,
    required this.textPrimary,
    required this.textSecondary,
    required this.textMuted,
    required this.positive,
    required this.positiveText,
    required this.positiveBg,
    required this.negative,
    required this.negativeText,
    required this.negativeBg,
  });

  final Color background;
  final Color surface;
  final Color card;
  final Color border;
  final Color overlay;
  final Color textPrimary;
  final Color textSecondary;
  final Color textMuted;
  final Color positive;
  final Color positiveText;
  final Color positiveBg;
  final Color negative;
  final Color negativeText;
  final Color negativeBg;

  @override
  AppThemeColors copyWith({
    Color? background,
    Color? surface,
    Color? card,
    Color? border,
    Color? overlay,
    Color? textPrimary,
    Color? textSecondary,
    Color? textMuted,
    Color? positive,
    Color? positiveText,
    Color? positiveBg,
    Color? negative,
    Color? negativeText,
    Color? negativeBg,
  }) {
    return AppThemeColors(
      background: background ?? this.background,
      surface: surface ?? this.surface,
      card: card ?? this.card,
      border: border ?? this.border,
      overlay: overlay ?? this.overlay,
      textPrimary: textPrimary ?? this.textPrimary,
      textSecondary: textSecondary ?? this.textSecondary,
      textMuted: textMuted ?? this.textMuted,
      positive: positive ?? this.positive,
      positiveText: positiveText ?? this.positiveText,
      positiveBg: positiveBg ?? this.positiveBg,
      negative: negative ?? this.negative,
      negativeText: negativeText ?? this.negativeText,
      negativeBg: negativeBg ?? this.negativeBg,
    );
  }

  @override
  AppThemeColors lerp(AppThemeColors? other, double t) {
    if (other == null) return this;
    return AppThemeColors(
      background: Color.lerp(background, other.background, t)!,
      surface: Color.lerp(surface, other.surface, t)!,
      card: Color.lerp(card, other.card, t)!,
      border: Color.lerp(border, other.border, t)!,
      overlay: Color.lerp(overlay, other.overlay, t)!,
      textPrimary: Color.lerp(textPrimary, other.textPrimary, t)!,
      textSecondary: Color.lerp(textSecondary, other.textSecondary, t)!,
      textMuted: Color.lerp(textMuted, other.textMuted, t)!,
      positive: Color.lerp(positive, other.positive, t)!,
      positiveText: Color.lerp(positiveText, other.positiveText, t)!,
      positiveBg: Color.lerp(positiveBg, other.positiveBg, t)!,
      negative: Color.lerp(negative, other.negative, t)!,
      negativeText: Color.lerp(negativeText, other.negativeText, t)!,
      negativeBg: Color.lerp(negativeBg, other.negativeBg, t)!,
    );
  }

  // ── Hazır paletler ──────────────────────────────────────────────────────

  /// Karanlik (Dark Classic)
  static const darkClassic = AppThemeColors(
    background: Color(0xFF141518),
    surface: Color(0xFF1A1D22),
    card: Color(0xFF21262D),
    border: Color(0xFF2F3641),
    overlay: Color(0xFF262D38),
    textPrimary: Color(0xFFF2F5FA),
    textSecondary: Color(0xFF9AA3B2),
    textMuted: Color(0xFF636C7A),
    positive: Color(0xFF52C47A),
    positiveText: Color(0xFF72D99A),
    positiveBg: Color(0xFF182A20),
    negative: Color(0xFFD46B6B),
    negativeText: Color(0xFFE89090),
    negativeBg: Color(0xFF2E1A1A),
  );

  /// Gece Mavisi (Midnight Blue)
  static const midnightBlue = AppThemeColors(
    background: Color(0xFF0F1A2A),
    surface: Color(0xFF16243A),
    card: Color(0xFF1B2C45),
    border: Color(0xFF2B3E5D),
    overlay: Color(0xFF223655),
    textPrimary: Color(0xFFE9F1FF),
    textSecondary: Color(0xFF8FA8CC),
    textMuted: Color(0xFF5E7899),
    positive: Color(0xFF4DA8D4),
    positiveText: Color(0xFF72C0E8),
    positiveBg: Color(0xFF0E2233),
    negative: Color(0xFFD47A6A),
    negativeText: Color(0xFFE89A8C),
    negativeBg: Color(0xFF2A1A18),
  );

  /// Alacakaranlik (Twilight)
  static const twilight = AppThemeColors(
    background: Color(0xFF1D1A2B),
    surface: Color(0xFF26213A),
    card: Color(0xFF2C2743),
    border: Color(0xFF3F385C),
    overlay: Color(0xFF373050),
    textPrimary: Color(0xFFF1EFFF),
    textSecondary: Color(0xFF9D96C0),
    textMuted: Color(0xFF6B6490),
    positive: Color(0xFF8A72D4),
    positiveText: Color(0xFFAA96E8),
    positiveBg: Color(0xFF1E1830),
    negative: Color(0xFFD47A9A),
    negativeText: Color(0xFFE89AB8),
    negativeBg: Color(0xFF2A1824),
  );

  /// Gun Batimi (Sunset)
  static const sunset = AppThemeColors(
    background: Color(0xFF2A1716),
    surface: Color(0xFF36201E),
    card: Color(0xFF402724),
    border: Color(0xFF5A3834),
    overlay: Color(0xFF4A2E2A),
    textPrimary: Color(0xFFFFEFE9),
    textSecondary: Color(0xFFCCA090),
    textMuted: Color(0xFF8A6458),
    positive: Color(0xFFD4956A),
    positiveText: Color(0xFFE8B48C),
    positiveBg: Color(0xFF2E1E14),
    negative: Color(0xFFD46A6A),
    negativeText: Color(0xFFE89090),
    negativeBg: Color(0xFF2E1414),
  );

  /// Aydinlik (Light)
  static const light = AppThemeColors(
    background: Color(0xFFFAFBFC),
    surface: Color(0xFFFFFFFF),
    card: Color(0xFFFFFFFF),
    border: Color(0xFFE1E8F0),
    overlay: Color(0xFFF0F4F9),
    textPrimary: Color(0xFF0F1419),
    textSecondary: Color(0xFF57606A),
    textMuted: Color(0xFF8B95A5),
    positive: Color(0xFF34A853),
    positiveText: Color(0xFF1E8449),
    positiveBg: Color(0xFFE6F4EA),
    negative: Color(0xFFEA4335),
    negativeText: Color(0xFFC5221F),
    negativeBg: Color(0xFFFCE8E6),
  );

  /// Gun Dogumu (Sunrise)
  static const sunrise = AppThemeColors(
    background: Color(0xFFFFF6EC),
    surface: Color(0xFFFFFBF5),
    card: Color(0xFFFFFBF5),
    border: Color(0xFFE8D4BC),
    overlay: Color(0xFFF5E8D4),
    textPrimary: Color(0xFF3A2A1C),
    textSecondary: Color(0xFF6A5244),
    textMuted: Color(0xFF9A8070),
    positive: Color(0xFF8A6E2A),
    positiveText: Color(0xFF7A5E1A),
    positiveBg: Color(0xFFF5EDD8),
    negative: Color(0xFFB84A2A),
    negativeText: Color(0xFFA03A1A),
    negativeBg: Color(0xFFF8E8E0),
  );
}

/// Eski static sabitler — geriye dönük uyumluluk için korundu.
/// Yeni kod [context.appColors] kullanmalı.
abstract final class AppColors {
  static const Color background = Color(0xFF141518);
  static const Color surface = Color(0xFF1A1D22);
  static const Color card = Color(0xFF21262D);
  static const Color border = Color(0xFF2F3641);
  static const Color overlay = Color(0xFF262D38);
  static const Color textPrimary = Color(0xFFF2F5FA);
  static const Color textSecondary = Color(0xFF9AA3B2);
  static const Color textMuted = Color(0xFF636C7A);
  static const Color positive = Color(0xFF52C47A);
  static const Color positiveText = Color(0xFF72D99A);
  static const Color positiveBg = Color(0xFF182A20);
  static const Color negative = Color(0xFFD46B6B);
  static const Color negativeText = Color(0xFFE89090);
  static const Color negativeBg = Color(0xFF2E1A1A);
}

/// BuildContext extension — widget'larda `context.appColors.card` şeklinde kullanılır.
extension AppColorsContext on BuildContext {
  AppThemeColors get appColors =>
      Theme.of(this).extension<AppThemeColors>() ?? AppThemeColors.darkClassic;
}
