import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:no_name/core/theme/app_colors.dart';

enum AppThemePreset { midnightBlue, twilight, sunrise, darkClassic }

extension AppThemePresetLabel on AppThemePreset {
  String get label {
    switch (this) {
      case AppThemePreset.midnightBlue:
        return 'Gece Mavisi';
      case AppThemePreset.twilight:
        return 'Alacakaranlik';
      case AppThemePreset.sunrise:
        return 'Gun Dogumu';
      case AppThemePreset.darkClassic:
        return 'Karanlik';
    }
  }
}

extension AppThemePresetPreview on AppThemePreset {
  List<Color> get previewColors {
    final c = _colorsFor(this);
    return [c.background, c.card, c.positiveText];
  }
}

AppThemeColors _colorsFor(AppThemePreset preset) {
  switch (preset) {
    case AppThemePreset.midnightBlue:
      return AppThemeColors.midnightBlue;
    case AppThemePreset.twilight:
      return AppThemeColors.twilight;
    case AppThemePreset.sunrise:
      return AppThemeColors.sunrise;
    case AppThemePreset.darkClassic:
      return AppThemeColors.darkClassic;
  }
}

abstract final class AppTheme {
  static ThemeData darkTheme = themeFor(AppThemePreset.darkClassic);

  static ThemeData themeFor(AppThemePreset preset) {
    final c = _colorsFor(preset);
    final isLight = preset == AppThemePreset.sunrise;

    return ThemeData(
      brightness: isLight ? Brightness.light : Brightness.dark,
      fontFamily: 'SF Pro Text',
      scaffoldBackgroundColor: c.background,
      extensions: [c],
      colorScheme: ColorScheme(
        brightness: isLight ? Brightness.light : Brightness.dark,
        primary: c.positiveText,
        onPrimary: isLight ? Colors.white : c.background,
        secondary: c.textSecondary,
        onSecondary: isLight ? Colors.white : c.background,
        error: c.negativeText,
        onError: isLight ? Colors.white : c.background,
        surface: c.surface,
        onSurface: c.textPrimary,
        outline: c.border,
      ),
      textTheme: TextTheme(
        headlineLarge: TextStyle(
          fontWeight: FontWeight.w700,
          color: c.textPrimary,
          letterSpacing: -0.7,
        ),
        titleLarge: TextStyle(
          fontWeight: FontWeight.w700,
          color: c.textPrimary,
          letterSpacing: -0.5,
        ),
        titleMedium: TextStyle(
          fontWeight: FontWeight.w600,
          color: c.textPrimary,
        ),
        titleSmall: TextStyle(
          fontWeight: FontWeight.w400,
          color: c.textSecondary,
        ),
        bodyLarge: TextStyle(fontWeight: FontWeight.w400, color: c.textPrimary),
        bodyMedium: TextStyle(color: c.textSecondary, fontSize: 13),
        bodySmall: TextStyle(color: c.textMuted, fontSize: 11),
      ),
      dividerTheme: DividerThemeData(color: c.border, thickness: 0.5),
      cardTheme: CardThemeData(
        color: c.card,
        elevation: 0,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
        margin: EdgeInsets.zero,
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: c.surface,
        hintStyle: TextStyle(color: c.textMuted, fontSize: 13),
        labelStyle: TextStyle(color: c.textSecondary, fontSize: 12),
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 14,
          vertical: 12,
        ),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: BorderSide(color: c.border, width: 0.8),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: BorderSide(color: c.border, width: 0.8),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: BorderSide(color: c.positiveText, width: 1),
        ),
      ),
      listTileTheme: ListTileThemeData(
        iconColor: c.textSecondary,
        textColor: c.textPrimary,
      ),
      chipTheme: ChipThemeData(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        backgroundColor: c.surface,
        selectedColor: c.overlay,
        side: BorderSide(color: c.border, width: 0.6),
        labelStyle: TextStyle(color: c.textSecondary, fontSize: 12),
      ),
      pageTransitionsTheme: const PageTransitionsTheme(
        builders: {
          TargetPlatform.android: FadeForwardsPageTransitionsBuilder(),
          TargetPlatform.iOS: CupertinoPageTransitionsBuilder(),
          TargetPlatform.windows: FadeForwardsPageTransitionsBuilder(),
        },
      ),
      appBarTheme: AppBarTheme(
        backgroundColor: c.background,
        systemOverlayStyle: isLight
            ? SystemUiOverlayStyle.dark
            : SystemUiOverlayStyle.light,
        elevation: 0,
        scrolledUnderElevation: 0,
        centerTitle: false,
        titleTextStyle: TextStyle(
          color: c.textPrimary,
          fontSize: 18,
          fontWeight: FontWeight.w700,
          letterSpacing: -0.3,
        ),
        iconTheme: IconThemeData(color: c.textPrimary),
      ),
      useMaterial3: true,
    );
  }
}
